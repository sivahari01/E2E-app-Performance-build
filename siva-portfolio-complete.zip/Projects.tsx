// components/Projects.tsx
'use client';

import { motion } from 'framer-motion';
import { containerVariants, itemVariants, titleVariants, cardHoverVariants } from '@/lib/animations';
import { useState, useRef } from 'react';
import { ArrowUpRight, Zap, Database, Eye } from 'lucide-react';

interface Project {
  id: string;
  title: string;
  description: string;
  longDescription: string;
  icon: React.ReactNode;
  tags: string[];
  color: string;
  borderColor: string;
}

const projects: Project[] = [
  {
    id: 'ai-dashboard',
    title: 'AI-Powered Performance Dashboard',
    description: 'Automated performance reporting utilizing Google Gemini CLI',
    longDescription:
      'Built an intelligent performance monitoring dashboard that leverages Google Gemini CLI to generate automated performance reports. Features real-time metric analysis, AI-driven insights, and predictive performance recommendations.',
    icon: <Zap className="w-8 h-8" />,
    tags: ['Google Gemini', 'Performance Analytics', 'AI/ML', 'Dashboard'],
    color: 'from-orange-500/20 to-amber-500/10',
    borderColor: 'border-orange-500/30 hover:border-orange-500/70',
  },
  {
    id: 'microservices-pipeline',
    title: 'Microservices Scalability Pipeline',
    description: 'Advanced load testing for Spring Boot applications in Kubernetes',
    longDescription:
      'Designed and implemented a comprehensive load testing pipeline for Spring Boot microservices running in Kubernetes clusters. Integrated Apache JMeter with CI/CD for automated performance regression testing and scalability validation.',
    icon: <Database className="w-8 h-8" />,
    tags: ['Kubernetes', 'Spring Boot', 'JMeter', 'Load Testing', 'CI/CD'],
    color: 'from-blue-500/20 to-cyan-500/10',
    borderColor: 'border-blue-500/30 hover:border-blue-500/70',
  },
  {
    id: 'observability-integration',
    title: 'Observability Integration Platform',
    description: 'Real-time bottleneck identification with New Relic & Prometheus',
    longDescription:
      'Created an integrated observability platform combining New Relic and Prometheus to provide real-time visibility into system performance. Automated bottleneck detection using advanced metrics analysis and alerting mechanisms.',
    icon: <Eye className="w-8 h-8" />,
    tags: ['New Relic', 'Prometheus', 'Observability', 'Metrics', 'Alerting'],
    color: 'from-purple-500/20 to-pink-500/10',
    borderColor: 'border-purple-500/30 hover:border-purple-500/70',
  },
];

interface CardProps extends Project {
  index: number;
}

function ProjectCard({ id, title, description, longDescription, icon, tags, color, borderColor, index }: CardProps) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [mousePosition, setMousePosition] = useState({ x: 0, y: 0 });
  const [isHovered, setIsHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!cardRef.current) return;

    const rect = cardRef.current.getBoundingClientRect();
    const x = (e.clientX - rect.left) / rect.width - 0.5;
    const y = (e.clientY - rect.top) / rect.height - 0.5;

    setMousePosition({ x: x * 20, y: y * 20 });
  };

  const handleMouseLeave = () => {
    setMousePosition({ x: 0, y: 0 });
    setIsHovered(false);
  };

  return (
    <motion.div
      ref={cardRef}
      className={`p-6 md:p-8 rounded-2xl border-2 ${borderColor} bg-gradient-to-br ${color} backdrop-blur-sm cursor-pointer relative overflow-hidden group h-full transition-all duration-300`}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onMouseEnter={() => setIsHovered(true)}
      style={{
        transform: isHovered
          ? `perspective(1000px) rotateX(${mousePosition.y}deg) rotateY(${-mousePosition.x}deg) scale(1.02)`
          : 'perspective(1000px) rotateX(0deg) rotateY(0deg) scale(1)',
      }}
      transition={{ type: 'spring', stiffness: 300, damping: 30 }}
      whileHover={{
        boxShadow: '0 30px 60px rgba(245, 158, 11, 0.2)',
      }}
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      transition={{ delay: index * 0.15, duration: 0.6 }}
      viewport={{ once: true, amount: 0.3 }}
    >
      {/* Animated gradient background on hover */}
      <motion.div
        className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-br from-gold-500/10 to-transparent transition-opacity duration-300"
        animate={isHovered ? { opacity: 0.15 } : { opacity: 0 }}
      ></motion.div>

      {/* Content */}
      <div className="relative z-10 h-full flex flex-col">
        {/* Header */}
        <div className="flex items-start justify-between mb-6">
          <motion.div
            className="w-14 h-14 rounded-xl bg-gradient-to-br from-gold-500/30 to-gold-500/10 border border-gold-500/50 flex items-center justify-center text-gold-400 group-hover:text-gold-300 group-hover:bg-gold-500/40 transition-all"
            whileHover={{ scale: 1.1, rotate: 10 }}
            animate={isHovered ? { y: -4 } : { y: 0 }}
          >
            {icon}
          </motion.div>

          <motion.button
            className="w-10 h-10 rounded-lg bg-gold-500/20 border border-gold-500/30 flex items-center justify-center text-gold-400 hover:bg-gold-500/40 hover:border-gold-500/60 transition-all opacity-0 group-hover:opacity-100"
            whileHover={{ scale: 1.1, rotate: 45 }}
            whileTap={{ scale: 0.9 }}
          >
            <ArrowUpRight className="w-5 h-5" />
          </motion.button>
        </div>

        {/* Title and Description */}
        <div className="mb-4">
          <h3 className="text-xl md:text-2xl font-bold text-white mb-2 group-hover:text-gold-400 transition-colors">
            {title}
          </h3>
          <p className="text-gray-400 text-sm md:text-base mb-3">{description}</p>
          <p className="text-gray-500 text-xs md:text-sm leading-relaxed">{longDescription}</p>
        </div>

        {/* Tags */}
        <div className="flex-1"></div>
        <motion.div
          className="flex flex-wrap gap-2 pt-6 border-t border-gold-500/10"
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          {tags.map((tag, idx) => (
            <motion.span
              key={idx}
              className="px-3 py-1 rounded-full bg-gold-500/20 border border-gold-500/30 text-gold-300 text-xs font-medium hover:bg-gold-500/30 transition-all"
              initial={{ opacity: 0, scale: 0.8 }}
              whileInView={{ opacity: 1, scale: 1 }}
              transition={{ delay: 0.1 + idx * 0.05 }}
              viewport={{ once: true }}
            >
              {tag}
            </motion.span>
          ))}
        </motion.div>
      </div>

      {/* Corner accent */}
      <motion.div
        className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-bl from-gold-500/20 to-transparent rounded-bl-3xl opacity-0 group-hover:opacity-100 transition-opacity"
        animate={isHovered ? { scale: 1.2 } : { scale: 1 }}
      ></motion.div>
    </motion.div>
  );
}

export default function Projects() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-darkgray via-dark to-darker relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 right-40 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-40 left-0 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>

      <motion.div
        className="max-w-6xl mx-auto relative z-10"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        {/* Section Title */}
        <motion.div className="mb-16" variants={titleVariants}>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-2">Selected Works</h2>
          <p className="text-gray-400 text-lg">High-impact projects that demonstrate expertise</p>
          <div className="w-16 h-1 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full mt-4"></div>
        </motion.div>

        {/* Projects Grid */}
        <motion.div
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
          variants={containerVariants}
        >
          {projects.map((project, idx) => (
            <motion.div key={project.id} variants={itemVariants}>
              <ProjectCard {...project} index={idx} />
            </motion.div>
          ))}
        </motion.div>

        {/* Footer CTA */}
        <motion.div
          className="mt-16 text-center"
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.4 }}
          viewport={{ once: true }}
        >
          <p className="text-gray-400 mb-6">Interested in collaborating on a project?</p>
          <motion.a
            href="#contact"
            className="inline-flex items-center gap-2 px-8 py-4 rounded-lg bg-gradient-to-r from-gold-500 to-gold-600 text-dark font-semibold hover:shadow-glow-lg transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Get in Touch
            <ArrowUpRight className="w-5 h-5" />
          </motion.a>
        </motion.div>
      </motion.div>
    </section>
  );
}
