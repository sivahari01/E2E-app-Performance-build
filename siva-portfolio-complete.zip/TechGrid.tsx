// components/TechGrid.tsx
'use client';

import { motion } from 'framer-motion';
import { bentoItemVariants, containerVariants } from '@/lib/animations';
import { Zap, Server, BarChart3, Code2, Cpu, Database } from 'lucide-react';

interface TechCategory {
  id: string;
  title: string;
  icon: React.ReactNode;
  tools: string[];
  color: string;
  colSpan: string;
  rowSpan: string;
}

const techCategories: TechCategory[] = [
  {
    id: 'load-testing',
    title: 'Load Testing',
    icon: <BarChart3 className="w-6 h-6" />,
    tools: ['Apache JMeter', 'OpenText LoadRunner', 'Tricentis NeoLoad'],
    color: 'from-orange-500/20 to-red-500/10',
    colSpan: 'col-span-1 md:col-span-1',
    rowSpan: 'row-span-1',
  },
  {
    id: 'cloud',
    title: 'Containers & Cloud',
    icon: <Server className="w-6 h-6" />,
    tools: ['Docker', 'Kubernetes', 'Minikube', 'GitHub Codespaces'],
    color: 'from-blue-500/20 to-cyan-500/10',
    colSpan: 'col-span-1 md:col-span-1',
    rowSpan: 'row-span-1 md:row-span-2',
  },
  {
    id: 'observability',
    title: 'Observability',
    icon: <Zap className="w-6 h-6" />,
    tools: ['New Relic', 'Prometheus', 'Dynatrace', 'Datadog', 'Splunk', 'Kibana'],
    color: 'from-purple-500/20 to-pink-500/10',
    colSpan: 'col-span-1 md:col-span-2',
    rowSpan: 'row-span-1',
  },
  {
    id: 'dev',
    title: 'Dev & AI',
    icon: <Code2 className="w-6 h-6" />,
    tools: ['Java', 'Python', 'Oracle SQL', 'Google Gemini CLI'],
    color: 'from-emerald-500/20 to-teal-500/10',
    colSpan: 'col-span-1 md:col-span-1',
    rowSpan: 'row-span-1',
  },
];

export default function TechGrid() {
  return (
    <motion.div
      className="grid grid-cols-1 md:grid-cols-3 gap-6 auto-rows-max"
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, amount: 0.2 }}
    >
      {techCategories.map((category) => (
        <motion.div
          key={category.id}
          className={`${category.colSpan} ${category.rowSpan}`}
          variants={bentoItemVariants}
        >
          <motion.div
            className={`h-full p-6 md:p-8 rounded-2xl border border-gold-500/20 bg-gradient-to-br ${category.color} backdrop-blur-sm group cursor-pointer overflow-hidden relative`}
            whileHover={{
              boxShadow: '0 0 40px rgba(245, 158, 11, 0.3)',
              borderColor: 'rgb(245, 158, 11)',
            }}
            transition={{ duration: 0.3 }}
          >
            {/* Animated background gradient */}
            <motion.div
              className="absolute inset-0 opacity-0 group-hover:opacity-100 bg-gradient-to-br from-gold-500/10 to-transparent transition-opacity duration-300"
            ></motion.div>

            {/* Content */}
            <div className="relative z-10 h-full flex flex-col">
              {/* Header */}
              <div className="flex items-start justify-between mb-6">
                <div className="flex-1">
                  <motion.div
                    className="w-12 h-12 rounded-lg bg-gold-500/20 border border-gold-500/30 flex items-center justify-center mb-4 text-gold-400 group-hover:text-gold-300 group-hover:bg-gold-500/30 transition-all"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {category.icon}
                  </motion.div>
                  <h3 className="text-lg md:text-xl font-bold text-white">{category.title}</h3>
                </div>
              </div>

              {/* Tools List */}
              <div className="flex-1">
                <div className={`grid gap-2 ${
                  category.tools.length > 4 ? 'grid-cols-2' : 'grid-cols-1'
                }`}>
                  {category.tools.map((tool, idx) => (
                    <motion.div
                      key={idx}
                      className="px-3 py-2 rounded-lg bg-gold-500/10 border border-gold-500/20 text-gold-300 text-sm font-medium hover:bg-gold-500/20 hover:border-gold-500/40 transition-all duration-300"
                      whileHover={{ x: 4 }}
                      initial={{ opacity: 0, y: 8 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      transition={{ delay: idx * 0.05 }}
                      viewport={{ once: true }}
                    >
                      {tool}
                    </motion.div>
                  ))}
                </div>
              </div>

              {/* Hover indicator */}
              <motion.div
                className="mt-4 pt-4 border-t border-gold-500/10 text-gold-400 text-xs font-semibold opacity-0 group-hover:opacity-100 transition-opacity"
                initial={{ opacity: 0, y: -4 }}
              >
                ↗ Specialized expertise
              </motion.div>
            </div>
          </motion.div>
        </motion.div>
      ))}
    </motion.div>
  );
}
