# 🚀 RUN THE PORTFOLIO - Complete Setup Guide

## ⏱️ Total Time: 10 Minutes

This guide shows you exactly how to get your portfolio running locally and deployed.

---

## 📥 Step 1: Extract the ZIP File (2 min)

### Windows
1. Download `siva-portfolio-complete.zip`
2. Right-click → "Extract All"
3. Choose folder location
4. Click "Extract"

### Mac
1. Download `siva-portfolio-complete.zip`
2. Double-click to auto-extract
3. A folder named `siva-portfolio-complete` appears

### Linux
```bash
unzip siva-portfolio-complete.zip
cd siva-portfolio-complete
```

---

## ✅ Step 2: Prerequisites Check (1 min)

Before proceeding, ensure you have:

### Check Node.js Installation
```bash
node --version
# Should show v18 or higher
# Example: v18.17.0
```

**Don't have Node.js?**
→ Download from [nodejs.org](https://nodejs.org) (choose LTS version)

### Check npm Installation
```bash
npm --version
# Should show 9 or higher
# Example: 9.6.7
```

---

## 🎯 Step 3: Create Your Next.js Project (3 min)

Open Terminal/Command Prompt and run:

```bash
# Create a new Next.js project
npx create-next-app@latest siva-portfolio \
  --typescript \
  --tailwind \
  --eslint \
  --no-git

# Go into the project folder
cd siva-portfolio
```

**Answer the prompts:**
- `src/ directory?` → **Yes**
- Other options → Accept defaults

---

## 📦 Step 4: Install Extra Dependencies (2 min)

```bash
npm install framer-motion lucide-react
```

**What you're installing:**
- `framer-motion` - For animations
- `lucide-react` - For icons

---

## 📋 Step 5: Copy Files from ZIP to Your Project (2 min)

From the extracted ZIP folder, copy these files to your project:

### Option A: Manual Copy (Easiest for Beginners)

**Create folders:**
```
Inside your project root, create:
- src/components/   (if doesn't exist)
- src/lib/          (if doesn't exist)
```

**Copy these files:**

1. **Config files to PROJECT ROOT:**
   - `tailwind.config.js` → root
   - `next.config.js` → root
   - `tsconfig.json` → root
   - `package.json` → root (merge/replace)
   - `.env.example` → root (rename to `.env.local`)

2. **Component files to `src/components/`:**
   - `Hero.tsx`
   - `MetricsBar.tsx`
   - `About.tsx`
   - `TechGrid.tsx`
   - `Experience.tsx`
   - `Projects.tsx`
   - `Contact.tsx`

3. **App files to `src/app/`:**
   - `page.tsx` (replace existing)
   - `layout.tsx` (replace existing)
   - `globals.css` → `src/app/` or `src/styles/`

4. **Utility files to `src/lib/`:**
   - `animations.ts`

### Option B: Command Line Copy (Advanced)

**For Mac/Linux:**
```bash
# Copy components
cp src/components/* ../siva-portfolio/src/components/

# Copy app files
cp src/app/* ../siva-portfolio/src/app/

# Copy utilities
cp src/lib/* ../siva-portfolio/src/lib/

# Copy config files
cp *.js ../siva-portfolio/
cp *.json ../siva-portfolio/
```

---

## 🖼️ Step 6: Add Your Photo (1 min)

1. Create folder: `public/images/`
2. Add your portrait photo as: `1000089067.png`

**Photo recommendations:**
- Size: 600x800px or similar
- Format: PNG, JPG, or WebP
- Style: Professional/cinematic
- Portrait or landscape orientation works

The component will automatically add vignette and gold overlay effects!

---

## 🎨 Step 7: Update Your Information (5-10 min)

### Edit Your Hero Headline
**File:** `src/components/Hero.tsx`

Find this line:
```tsx
<h1>
  I DON'T JUST WRITE <span>CODE.</span>
  <br />
  <span>I ENGINEER SCALABILITY.</span>
</h1>
```

Replace with YOUR headline. Example:
```tsx
<h1>
  I BUILD <span>AMAZING</span> <span>THINGS.</span>
  <br />
  <span>WITH CODE & CREATIVITY.</span>
</h1>
```

### Edit Your Name & Bio
**File:** `src/components/About.tsx`

Find this section:
```tsx
<h3 className="text-3xl font-bold text-white">Siva</h3>
<p>Uthamapalayam, Tamil Nadu</p>
```

Replace with your name and location:
```tsx
<h3 className="text-3xl font-bold text-white">YOUR NAME</h3>
<p>YOUR CITY, YOUR STATE</p>
```

### Edit Your Bio Paragraphs
In same file, update:
```tsx
<p>I'm a Performance Engineer and System Reliability Specialist...</p>
```

Replace with YOUR bio.

### Edit Tech Stack
**File:** `src/components/TechGrid.tsx`

Find the `techCategories` array and update tools:
```tsx
const techCategories: TechCategory[] = [
  {
    id: 'frontend',
    title: 'Frontend',
    tools: ['React', 'Next.js', 'TypeScript', 'Tailwind CSS'],
    // ...
  },
  // Add more categories...
];
```

### Edit Projects
**File:** `src/components/Projects.tsx`

Find `const projects:` and update:
```tsx
{
  id: 'my-project',
  title: 'Your Project Name',
  description: 'Short description',
  longDescription: 'Detailed description',
  tags: ['Tag1', 'Tag2', 'Tag3'],
  // ...
}
```

### Edit Experience Timeline
**File:** `src/components/Experience.tsx`

Find `const timeline:` and update dates/titles:
```tsx
{
  date: 'January 2025',
  title: 'Your Title',
  description: 'Your description',
  // ...
}
```

---

## 🚀 Step 8: Run Development Server (1 min)

```bash
npm run dev
```

**You should see:**
```
> ready - started server on 0.0.0.0:3000, url: http://localhost:3000
```

---

## 👀 Step 9: View Your Portfolio (1 min)

### Open in Browser
1. Open your browser
2. Go to: `http://localhost:3000`
3. Your portfolio loads! 🎉

### Test It
- ✅ Click buttons
- ✅ Scroll through sections
- ✅ Check animations
- ✅ Resize browser to test mobile responsiveness

---

## 🔧 Step 10: Stop the Server (When Done)

To stop the server:
```bash
# Press Ctrl+C in terminal
```

To start again:
```bash
npm run dev
```

---

## 🌐 Step 11: Deploy to Live Web (Optional - 5 min)

### Option A: Deploy to Vercel (Easiest)

**1. Push to GitHub**
```bash
git init
git add .
git commit -m "Initial portfolio"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/siva-portfolio.git
git push -u origin main
```

**2. Go to Vercel**
- Visit [vercel.com](https://vercel.com)
- Sign up with GitHub
- Click "Import Project"
- Select your portfolio repo
- Click "Deploy"
- Done! Your site is live in 1 minute 🚀

### Option B: Deploy to Netlify

**1. Build your project**
```bash
npm run build
```

**2. Deploy**
- Visit [netlify.com](https://netlify.com)
- Drag & drop the `.next` folder
- Your site is live! 🚀

### Option C: Deploy to Your Own Server

**Build for production:**
```bash
npm run build
npm start
```

This starts a production server on port 3000.

---

## 📝 Complete File List

After setup, your project should have:

```
siva-portfolio/
├── .next/                    (Generated automatically)
├── node_modules/             (Generated automatically)
├── public/
│   └── images/
│       └── 1000089067.png    (Your photo)
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx
│   │   └── globals.css
│   ├── components/
│   │   ├── Hero.tsx
│   │   ├── MetricsBar.tsx
│   │   ├── About.tsx
│   │   ├── TechGrid.tsx
│   │   ├── Experience.tsx
│   │   ├── Projects.tsx
│   │   └── Contact.tsx
│   └── lib/
│       └── animations.ts
├── .env.local                (From .env.example)
├── tailwind.config.js
├── next.config.js
├── tsconfig.json
├── package.json
└── package-lock.json         (Generated automatically)
```

---

## ✅ Troubleshooting

### "npm: command not found"
→ Node.js not installed. Download from [nodejs.org](https://nodejs.org)

### "Error: Cannot find module 'framer-motion'"
```bash
npm install framer-motion lucide-react
```

### "Image not showing"
- Check `public/images/1000089067.png` exists
- Verify filename is correct in Hero.tsx
- Image must be PNG, JPG, or WebP format

### "Page looks broken"
```bash
rm -rf .next
npm run dev
```

### "Styles look wrong"
- Make sure `tailwind.config.js` is in project root
- Ensure `globals.css` is imported in `layout.tsx`
- Restart dev server: Stop with Ctrl+C, then `npm run dev`

### "Animations not working"
```bash
npm install framer-motion
npm run dev
```

---

## 🎯 Next Steps After Running

1. **Customize Everything**
   - Update your name, bio, tech stack
   - Add your photo
   - Add your projects

2. **Test Thoroughly**
   - Check on mobile (DevTools F12)
   - Click all buttons
   - Test form (if integrated with email)

3. **Optimize (Optional)**
   - Add Google Analytics
   - Integrate email service for contact form
   - Optimize images

4. **Deploy**
   - Push to GitHub
   - Deploy to Vercel (1 click)
   - Share your portfolio!

---

## 📚 Documentation Files to Read

1. **START_HERE.md** - Overview & quick reference
2. **QUICKSTART.md** - Alternative quick setup
3. **README.md** - Complete detailed guide
4. **COMPONENTS.md** - How to customize each component
5. **FILE_GUIDE.md** - File organization reference

---

## 🎓 Useful Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Start production server
npm start

# Check for errors
npm run lint

# Format code
npm run format
```

---

## 🎨 Quick Customization Cheat Sheet

| What to Change | File | Line/Section |
|---|---|---|
| Hero headline | `Hero.tsx` | `<h1>` tag |
| Your name | `About.tsx` | Line with "Siva" |
| Your bio | `About.tsx` | Bio paragraphs |
| Tech stack | `TechGrid.tsx` | `techCategories` array |
| Projects | `Projects.tsx` | `projects` array |
| Experience | `Experience.tsx` | `timeline` array |
| Contact info | `Contact.tsx` | Contact methods |
| Colors | `tailwind.config.js` | `gold` color palette |
| Animations | `animations.ts` | Variant definitions |

---

## 💡 Pro Tips

✅ **Use VS Code** - Best editor for this project
✅ **Install Tailwind Intellisense** - Extension for autocomplete
✅ **Keep DevTools Open** - Check console for errors (F12)
✅ **Test Mobile First** - Use DevTools device emulation
✅ **Commit Often** - Use Git to track changes
✅ **Read Comments** - Code has helpful inline comments

---

## 🚀 Success Checklist

After following all steps, you should have:

- [ ] Node.js 18+ installed
- [ ] Project created with `create-next-app`
- [ ] Dependencies installed (`npm install framer-motion lucide-react`)
- [ ] All files copied to correct locations
- [ ] Your photo added to `public/images/`
- [ ] Basic information updated (name, bio)
- [ ] Dev server running (`npm run dev`)
- [ ] Portfolio visible at `http://localhost:3000`
- [ ] No console errors (F12 → Console)
- [ ] Mobile responsive works (F12 device emulation)

---

## 📞 Still Need Help?

### Check Documentation
- `START_HERE.md` - Entry point
- `README.md` - Full reference
- `COMPONENTS.md` - Component details
- `FILE_GUIDE.md` - File organization

### Watch Tutorial (Optional)
- Search "Next.js portfolio tutorial"
- Look for tutorials using Framer Motion + Tailwind

### Community Help
- Stack Overflow: Tag with `[next.js]`
- GitHub Discussions
- React community forums

---

## 🎉 You're Ready!

Everything is set up. Now:

1. Open terminal in your project folder
2. Run: `npm run dev`
3. Open: `http://localhost:3000`
4. See your portfolio live! 🚀

**Happy building!**

---

**Version:** 1.0.0
**Updated:** 2025
**Difficulty:** Beginner-friendly
**Time Required:** 10 minutes
