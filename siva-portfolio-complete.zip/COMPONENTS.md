# 📦 Components Documentation

Complete guide to all portfolio components with props and customization options.

## Component Structure

```
src/components/
├── Hero.tsx           - Main hero section with CTA
├── MetricsBar.tsx    - Statistics display
├── About.tsx         - About section with bio
├── TechGrid.tsx      - Bento box tech stack
├── Experience.tsx    - Timeline component
├── Projects.tsx      - Interactive project cards
└── Contact.tsx       - Terminal-style contact form
```

---

## Hero Component

The hero section with headline, image, and CTA buttons.

### Usage
```tsx
import Hero from '@/components/Hero';

export default function Page() {
  return <Hero />;
}
```

### Customization

**Edit headline** in `Hero.tsx`:
```tsx
<h1>
  I DON'T JUST WRITE <span>CODE.</span>
  <br />
  <span>I ENGINEER SCALABILITY.</span>
</h1>
```

**Edit sub-roles**:
```tsx
{['Performance Engineer', 'System Reliability', 'Cloud Architecture'].map(...)}
```

**Edit description**:
```tsx
<p>Specialized in identifying system bottlenecks...</p>
```

**Edit buttons**:
```tsx
<motion.button>Explore My Work</motion.button>
<motion.button>Download Resume</motion.button>
```

### Features
- Cinematic image with vignette effect
- Gold gradient overlay on photo
- Animated badge and role tags
- Responsive CTA buttons
- Integrated MetricsBar

---

## MetricsBar Component

Displays statistics row at bottom of hero section.

### Usage
```tsx
import MetricsBar from '@/components/MetricsBar';

export default function Page() {
  return <MetricsBar />;
}
```

### Customization

**Edit metrics** in `MetricsBar.tsx`:
```tsx
const metrics: Metric[] = [
  { value: '4.5+', label: 'Years Experience' },
  { value: '∞', label: 'Observability Expert' },
  { value: '✓', label: 'Scalability Tested' },
];
```

### Features
- Animated counter effect
- Responsive grid layout
- Gradient text values

---

## About Component

Bio section with tech stack grid.

### Usage
```tsx
import About from '@/components/About';

export default function Page() {
  return <About />;
}
```

### Customization

**Edit name and location**:
```tsx
<h3 className="text-3xl font-bold text-white">Siva</h3>
<p className="text-gray-400 flex items-center gap-2">
  <MapPin className="w-4 h-4 text-gold-400" />
  Uthamapalayam, Tamil Nadu
</p>
```

**Edit bio**:
```tsx
<p>I'm a Performance Engineer and System Reliability Specialist...</p>
```

**Edit stats card**:
```tsx
<div>
  <p className="text-gold-400">Experience</p>
  <p className="text-2xl font-bold">4.5+ Years</p>
</div>
```

### Features
- Bio with location
- Quick stats card
- Integrated TechGrid
- Responsive layout

---

## TechGrid Component

Bento box layout for tech stack categories.

### Usage
```tsx
import TechGrid from '@/components/TechGrid';

export default function Page() {
  return <TechGrid />;
}
```

### Customization

**Edit tech categories**:
```tsx
const techCategories: TechCategory[] = [
  {
    id: 'load-testing',
    title: 'Load Testing',
    icon: <BarChart3 className="w-6 h-6" />,
    tools: ['Apache JMeter', 'OpenText LoadRunner'],
    color: 'from-orange-500/20 to-red-500/10',
    colSpan: 'col-span-1 md:col-span-1',
    rowSpan: 'row-span-1',
  },
  // Add more categories...
];
```

**Grid positions** (adjust colSpan/rowSpan):
- `col-span-1` - 1 column
- `col-span-2` - 2 columns
- `row-span-2` - 2 rows tall

### Features
- Responsive bento grid
- Icon + title + tools
- Hover effects
- Color-coded categories

---

## Experience Component

Timeline with career milestones.

### Usage
```tsx
import Experience from '@/components/Experience';

export default function Page() {
  return <Experience />;
}
```

### Customization

**Edit timeline events**:
```tsx
const timeline: TimelineEvent[] = [
  {
    date: 'March 21, 2022',
    title: 'Career Begins',
    description: 'Started my journey as a performance engineer...',
    icon: <CheckCircle className="w-6 h-6" />,
    isHighlight: false,
    isPrimary: true,
  },
  // Add more events...
];
```

**Event properties:**
- `date` - Date string
- `title` - Event title
- `description` - Event details
- `icon` - Icon component
- `isHighlight` - Highlight with special styling (true/false)
- `isPrimary` - Show pulsing ring (true/false)

### Features
- Vertical timeline
- Animated dots and connectors
- Highlight cards for important events
- Pulsing indicator for primary events
- Responsive layout

---

## Projects Component

Interactive project cards with 3D effects.

### Usage
```tsx
import Projects from '@/components/Projects';

export default function Page() {
  return <Projects />;
}
```

### Customization

**Edit projects**:
```tsx
const projects: Project[] = [
  {
    id: 'ai-dashboard',
    title: 'AI-Powered Performance Dashboard',
    description: 'Automated performance reporting',
    longDescription: 'Built an intelligent dashboard...',
    icon: <Zap className="w-8 h-8" />,
    tags: ['Google Gemini', 'Performance Analytics'],
    color: 'from-orange-500/20 to-amber-500/10',
    borderColor: 'border-orange-500/30 hover:border-orange-500/70',
  },
  // Add more projects...
];
```

**Project properties:**
- `id` - Unique identifier
- `title` - Project name
- `description` - Short description
- `longDescription` - Detailed description
- `icon` - Project icon
- `tags` - Technology tags
- `color` - Gradient background
- `borderColor` - Border color with hover state

### Features
- 3D tilt hover effect
- Interactive cards
- Tag display
- Icon with hover animation
- Responsive grid

---

## Contact Component

Terminal-style contact form.

### Usage
```tsx
import Contact from '@/components/Contact';

export default function Page() {
  return <Contact />;
}
```

### Customization

**Edit form fields**:
```tsx
<input
  type="text"
  name="name"
  placeholder="Your name"
  // Update label and placeholder
/>
```

**Edit form submission**:
```tsx
const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault();
  // Add your email integration here
};
```

**Edit contact methods**:
```tsx
{
  label: 'Email',
  value: 'siva@example.com',
  icon: '📧',
}
```

**Edit terminal text**:
```tsx
<p className="text-gold-400 font-mono text-sm">$ message --send</p>
```

### Features
- Terminal aesthetic
- Form validation
- Loading state
- Success message
- Terminal header/footer
- Contact method cards

---

## Animation Variants Guide

All components use animation variants from `src/lib/animations.ts`.

### Available Variants

**Hero Animations**
```typescript
heroVariants        // Initial hero entrance
heroImageVariants   // Image with 3D perspective
```

**Container Animations**
```typescript
containerVariants   // Stagger children
```

**Item Animations**
```typescript
itemVariants        // Individual items in container
```

**Scroll Animations**
```typescript
scrollRevealVariants // Trigger on scroll
```

**Card Animations**
```typescript
cardHoverVariants   // 3D tilt effect
```

**Hover Effects**
```typescript
buttonVariants      // Button hover/tap
```

### Using Animations

```tsx
<motion.div
  initial="hidden"
  whileInView="visible"
  viewport={{ once: true, amount: 0.2 }}
  variants={containerVariants}
>
  Content
</motion.div>
```

---

## Icon Library

Components use `lucide-react` for icons:

```tsx
import {
  Download,
  ArrowRight,
  MapPin,
  Briefcase,
  CheckCircle,
  Star,
  Award,
  Zap,
  Database,
  Eye,
  Send,
  ArrowUpRight,
} from 'lucide-react';
```

Find more icons at [lucide.dev](https://lucide.dev)

---

## Responsive Behavior

All components use Tailwind responsive prefixes:

```
sm:  640px
md:  768px
lg:  1024px
xl:  1280px
2xl: 1536px
```

Example:
```tsx
<div className="text-sm md:text-lg lg:text-xl">
  Responsive text
</div>
```

---

## State Management

Components use React hooks for state:

```tsx
import { useState, useRef } from 'react';

export default function Component() {
  const [state, setState] = useState(initialValue);
  const ref = useRef(null);
  
  return (
    // JSX
  );
}
```

---

## Performance Considerations

- **Image Optimization**: Uses Next.js Image component
- **Animation Performance**: Uses GPU-accelerated properties (transform, opacity)
- **Code Splitting**: Components are automatically code-split
- **Lazy Loading**: Below-fold content lazy loads with `whileInView`

---

## Accessibility

Components include:
- Semantic HTML
- ARIA labels where needed
- Focus states
- Keyboard navigation support
- Color contrast compliance

---

## Browser Support

- Chrome/Edge (latest)
- Firefox (latest)
- Safari (latest)
- Mobile browsers (iOS Safari, Chrome Mobile)

---

## Troubleshooting

### Animation not working?
- Check Framer Motion is installed
- Verify variant names match
- Check `whileInView` viewport settings

### Component not rendering?
- Verify import path is correct
- Check component is not commented out
- Look for console errors

### Styling issues?
- Ensure Tailwind CSS is configured
- Check class names are correct
- Verify color values exist in tailwind.config.js

### Responsive issues?
- Test with DevTools device emulation
- Check breakpoint prefixes (sm:, md:, lg:)
- Verify container width is correct

---

## Best Practices

1. **Keep components focused** - One responsibility per component
2. **Use variants** - Leverage predefined animation variants
3. **Lazy load** - Use `whileInView` for below-fold content
4. **Optimize images** - Use Next.js Image component
5. **Type everything** - Use TypeScript for type safety
6. **Test responsive** - Always test on multiple screen sizes

---

**Last Updated:** 2025
**Version:** 1.0.0
