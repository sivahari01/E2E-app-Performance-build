// components/Experience.tsx
'use client';

import { motion } from 'framer-motion';
import { containerVariants, itemVariants, titleVariants, timelineVariants } from '@/lib/animations';
import { CheckCircle, Star, Award } from 'lucide-react';

interface TimelineEvent {
  date: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  isHighlight?: boolean;
  isPrimary?: boolean;
}

const timeline: TimelineEvent[] = [
  {
    date: 'March 21, 2022',
    title: 'Professional Engineering Career Begins',
    description: 'Started my journey as a performance engineer, focusing on system optimization and reliability.',
    icon: <CheckCircle className="w-6 h-6" />,
    isPrimary: true,
  },
  {
    date: 'July 2025',
    title: 'Joined Current IT Company',
    description: 'Transitioned to a new role focusing on scalability, microservices architecture, and cloud-native solutions.',
    icon: <Star className="w-6 h-6" />,
    isPrimary: true,
  },
  {
    date: 'NSA Phase 1 Initiative',
    title: 'Technical Excellence Award Nomination',
    description:
      'Nominated for technical excellence and leadership recognition during the NSA Phase 1 performance testing initiative. Demonstrated exceptional problem-solving and architectural insights.',
    icon: <Award className="w-6 h-6" />,
    isHighlight: true,
  },
];

export default function Experience() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark via-dark to-darkgray relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-40 left-0 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 right-20 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>

      <motion.div
        className="max-w-4xl mx-auto relative z-10"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        {/* Section Title */}
        <motion.div className="mb-16" variants={titleVariants}>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-2">Experience & Milestones</h2>
          <div className="w-16 h-1 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full"></div>
        </motion.div>

        {/* Timeline Container */}
        <div className="relative">
          {/* Timeline line */}
          <motion.div
            className="absolute left-0 md:left-1/2 w-1 h-full bg-gradient-to-b from-gold-500/50 via-gold-500/30 to-gold-500/10 rounded-full md:transform md:-translate-x-1/2"
            initial={{ scaleY: 0 }}
            whileInView={{ scaleY: 1 }}
            transition={{ duration: 1.5 }}
            viewport={{ once: true }}
          ></motion.div>

          {/* Timeline Events */}
          <motion.div className="space-y-12" variants={containerVariants}>
            {timeline.map((event, idx) => (
              <motion.div
                key={idx}
                className={`relative md:grid md:grid-cols-2 md:gap-8 ${
                  idx % 2 === 0 ? '' : 'md:flex md:flex-row-reverse'
                }`}
                variants={itemVariants}
              >
                {/* Left content (for odd indices on desktop) */}
                <motion.div
                  className={`md:col-span-1 md:text-right md:pr-8 ${
                    idx % 2 === 1 ? 'md:order-2 md:text-left md:pl-8 md:pr-0' : ''
                  }`}
                  variants={timelineVariants}
                >
                  <motion.div
                    className={`p-6 rounded-xl border ${
                      event.isHighlight
                        ? 'border-gold-500/50 bg-gradient-to-br from-gold-500/20 to-gold-500/5'
                        : 'border-gold-500/20 bg-gradient-to-br from-gold-500/10 to-darkgray'
                    } backdrop-blur-sm hover:border-gold-500/70 transition-all duration-300`}
                    whileHover={{
                      boxShadow: event.isHighlight
                        ? '0 0 40px rgba(245, 158, 11, 0.4)'
                        : '0 0 30px rgba(245, 158, 11, 0.2)',
                    }}
                  >
                    <p className="text-gold-400 text-sm font-semibold uppercase tracking-wider mb-2">
                      {event.date}
                    </p>

                    <h3 className="text-xl md:text-2xl font-bold text-white mb-2">{event.title}</h3>

                    <p className="text-gray-300 text-sm md:text-base leading-relaxed">{event.description}</p>

                    {event.isHighlight && (
                      <motion.div
                        className="mt-4 inline-flex items-center gap-2 px-3 py-1 rounded-full bg-gold-500/20 border border-gold-500/30"
                        initial={{ opacity: 0, scale: 0.8 }}
                        whileInView={{ opacity: 1, scale: 1 }}
                        transition={{ delay: 0.2 }}
                      >
                        <span className="w-1.5 h-1.5 bg-gold-400 rounded-full animate-pulse"></span>
                        <span className="text-xs font-semibold text-gold-300">Highlight</span>
                      </motion.div>
                    )}
                  </motion.div>
                </motion.div>

                {/* Center dot and icon */}
                <motion.div
                  className="absolute left-0 md:left-1/2 w-8 h-8 md:w-10 md:h-10 top-0 md:top-6 md:transform md:-translate-x-1/2 -translate-x-1/2 z-10"
                  initial={{ scale: 0 }}
                  whileInView={{ scale: 1 }}
                  transition={{ delay: 0.1, type: 'spring', stiffness: 100 }}
                  viewport={{ once: true }}
                >
                  <motion.div
                    className={`w-full h-full rounded-full border-4 flex items-center justify-center ${
                      event.isHighlight
                        ? 'bg-gold-500 border-dark text-white'
                        : 'bg-gradient-to-br from-gold-400 to-gold-500 border-dark text-white'
                    }`}
                    whileHover={{ scale: 1.2 }}
                  >
                    {event.icon}
                  </motion.div>

                  {/* Pulsing ring */}
                  {event.isPrimary && (
                    <motion.div
                      className="absolute inset-0 rounded-full border-2 border-gold-500"
                      animate={{ scale: [1, 1.4], opacity: [1, 0] }}
                      transition={{ duration: 2, repeat: Infinity }}
                    ></motion.div>
                  )}
                </motion.div>

                {/* Right content (for even indices on desktop) */}
                <div className="md:col-span-1 hidden"></div>
              </motion.div>
            ))}
          </motion.div>
        </div>

        {/* CTA Section */}
        <motion.div
          className="mt-16 p-8 rounded-2xl border border-gold-500/20 bg-gradient-to-r from-gold-500/10 via-darkgray to-dark backdrop-blur-sm text-center"
          variants={itemVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          <p className="text-gray-300 mb-4">Currently open to opportunities in performance engineering and system architecture</p>
          <motion.a
            href="#contact"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-gradient-to-r from-gold-500 to-gold-600 text-dark font-semibold hover:shadow-glow-lg transition-all"
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Let's Connect
            <span>→</span>
          </motion.a>
        </motion.div>
      </motion.div>
    </section>
  );
}
