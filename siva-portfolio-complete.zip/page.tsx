// app/page.tsx
'use client';

import { motion } from 'framer-motion';
import Hero from '@/components/Hero';
import About from '@/components/About';
import Experience from '@/components/Experience';
import Projects from '@/components/Projects';
import Contact from '@/components/Contact';

export default function Home() {
  return (
    <motion.main className="bg-dark text-white overflow-x-hidden">
      {/* Smooth scroll behavior */}
      <style>{`
        html {
          scroll-behavior: smooth;
        }
        
        /* Hide scrollbar while keeping functionality */
        ::-webkit-scrollbar {
          width: 8px;
        }
        
        ::-webkit-scrollbar-track {
          background: rgba(10, 14, 39, 0.8);
        }
        
        ::-webkit-scrollbar-thumb {
          background: linear-gradient(180deg, rgba(245, 158, 11, 0.5), rgba(217, 119, 6, 0.3));
          border-radius: 4px;
        }
        
        ::-webkit-scrollbar-thumb:hover {
          background: linear-gradient(180deg, rgba(245, 158, 11, 0.7), rgba(217, 119, 6, 0.5));
        }
      `}</style>

      {/* Navigation */}
      <motion.nav
        className="fixed top-0 left-0 right-0 h-16 bg-dark/80 backdrop-blur-md border-b border-gold-500/10 z-50"
        initial={{ y: -80 }}
        animate={{ y: 0 }}
        transition={{ duration: 0.6 }}
      >
        <div className="max-w-7xl mx-auto h-full px-4 sm:px-6 lg:px-8 flex items-center justify-between">
          {/* Logo */}
          <motion.a
            href="#"
            className="flex items-center gap-2 group"
            whileHover={{ scale: 1.05 }}
          >
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-600 flex items-center justify-center">
              <span className="text-dark font-bold">S</span>
            </div>
            <span className="text-white font-bold hidden sm:inline">SIVA</span>
          </motion.a>

          {/* Nav Links */}
          <div className="flex items-center gap-8">
            <nav className="hidden md:flex gap-8">
              {[
                { label: 'About', href: '#about' },
                { label: 'Experience', href: '#experience' },
                { label: 'Work', href: '#work' },
                { label: 'Contact', href: '#contact' },
              ].map((item) => (
                <motion.a
                  key={item.label}
                  href={item.href}
                  className="text-gray-400 hover:text-gold-400 transition-colors text-sm font-medium"
                  whileHover={{ y: -2 }}
                >
                  {item.label}
                </motion.a>
              ))}
            </nav>

            {/* CTA Button */}
            <motion.a
              href="#contact"
              className="px-4 py-2 rounded-lg bg-gradient-to-r from-gold-500 to-gold-600 text-dark font-semibold text-sm hover:shadow-glow transition-all"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.95 }}
            >
              Hire Me
            </motion.a>
          </div>
        </div>
      </motion.nav>

      {/* Main Content */}
      <Hero />
      
      <section id="about">
        <About />
      </section>

      <section id="experience">
        <Experience />
      </section>

      <section id="work">
        <Projects />
      </section>

      <section id="contact">
        <Contact />
      </section>

      {/* Footer */}
      <motion.footer
        className="py-12 px-4 sm:px-6 lg:px-8 border-t border-gold-500/10 bg-darker"
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        transition={{ duration: 0.6 }}
        viewport={{ once: true }}
      >
        <div className="max-w-7xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
            {/* Brand */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              viewport={{ once: true }}
            >
              <h3 className="text-xl font-bold text-white mb-2">Siva</h3>
              <p className="text-gray-400 text-sm">Performance Engineer | System Reliability Specialist</p>
            </motion.div>

            {/* Quick Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.15 }}
              viewport={{ once: true }}
            >
              <h4 className="text-white font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-gray-400 text-sm">
                <li><a href="#about" className="hover:text-gold-400 transition-colors">About</a></li>
                <li><a href="#experience" className="hover:text-gold-400 transition-colors">Experience</a></li>
                <li><a href="#work" className="hover:text-gold-400 transition-colors">Projects</a></li>
              </ul>
            </motion.div>

            {/* Social Links */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.2 }}
              viewport={{ once: true }}
            >
              <h4 className="text-white font-semibold mb-4">Connect</h4>
              <div className="flex gap-4">
                {['LinkedIn', 'GitHub', 'Twitter'].map((social) => (
                  <motion.a
                    key={social}
                    href="#"
                    className="text-gray-400 hover:text-gold-400 transition-colors"
                    whileHover={{ scale: 1.1, rotate: 5 }}
                  >
                    {social}
                  </motion.a>
                ))}
              </div>
            </motion.div>
          </div>

          {/* Bottom Bar */}
          <motion.div
            className="pt-8 border-t border-gold-500/10 flex flex-col md:flex-row items-center justify-between text-gray-500 text-sm"
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            viewport={{ once: true }}
          >
            <p>&copy; 2025 Siva. All rights reserved.</p>
            <p className="font-mono">Engineered with precision and passion</p>
          </motion.div>
        </div>
      </motion.footer>

      {/* Scroll to Top Button */}
      <motion.button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className="fixed bottom-8 right-8 w-12 h-12 rounded-full bg-gradient-to-r from-gold-500 to-gold-600 text-dark flex items-center justify-center font-bold hover:shadow-glow-lg transition-all z-40"
        initial={{ opacity: 0, scale: 0 }}
        whileInView={{ opacity: 1, scale: 1 }}
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
        viewport={{ once: false }}
      >
        ↑
      </motion.button>
    </motion.main>
  );
}
