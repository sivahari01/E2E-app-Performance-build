# Siva - Premium Performance Engineer Portfolio

A stunning, modern portfolio website built with Next.js, React, Framer Motion, and Tailwind CSS. Features a dark theme with gold accents, smooth animations, and an interactive terminal-style contact form.

## 🚀 Features

✨ **Modern Dark Theme** with premium gold/amber accents
🎬 **Cinematic Hero Section** with professional photography
⚡ **Smooth Scroll Animations** with Framer Motion
🎨 **Bento Box Tech Grid** displaying skill categories
📊 **Interactive Metrics** with animated counters
🎯 **3D Hover Effects** on project cards
💻 **Terminal-Style Contact Form** for developer aesthetic
📱 **Fully Responsive** design (mobile-first)
🔄 **Smooth Page Transitions** and reveal effects
📈 **Performance Optimized** with Next.js best practices

## 📋 Requirements

- Node.js 18+ and npm 9+
- Modern web browser (Chrome, Firefox, Safari, Edge)

## 🛠️ Installation & Setup

### 1. Create a new Next.js project

```bash
npx create-next-app@latest siva-portfolio \
  --typescript \
  --tailwind \
  --eslint \
  --no-git \
  --src-dir
```

### 2. Navigate to the project

```bash
cd siva-portfolio
```

### 3. Install additional dependencies

```bash
npm install framer-motion lucide-react
```

### 4. Set up the project structure

```bash
# Create directories
mkdir -p src/components src/lib src/styles public/images

# Copy files
# Copy all provided component files to src/components/
# Copy animations.ts to src/lib/
# Copy globals.css to src/styles/ or app/
# Copy tailwind.config.js to root
# Copy next.config.js to root
```

### 5. Add your hero image

Place your portrait photo at `public/images/1000089067.png`

The component expects an image with these specs:
- **Dimensions:** Landscape/portrait (recommended 600x800px or similar)
- **Format:** PNG, JPG, or WebP
- **Style:** Professional/cinematic (the included styling adds vignette and warm overlay)

### 6. Run development server

```bash
npm run dev
```

Visit `http://localhost:3000` in your browser.

## 📁 Project Structure

```
siva-portfolio/
├── src/
│   ├── app/
│   │   ├── layout.tsx          # Root layout with metadata
│   │   ├── page.tsx            # Main landing page
│   │   └── globals.css         # Global styles
│   ├── components/
│   │   ├── Hero.tsx            # Hero section with CTA
│   │   ├── About.tsx           # About & bio section
│   │   ├── TechGrid.tsx        # Bento box tech stack
│   │   ├── Experience.tsx      # Timeline component
│   │   ├── Projects.tsx        # Interactive project cards
│   │   ├── Contact.tsx         # Terminal-style form
│   │   └── MetricsBar.tsx      # Stats display
│   └── lib/
│       └── animations.ts       # Framer Motion variants
├── public/
│   └── images/
│       └── 1000089067.png      # Your hero photo
├── tailwind.config.js          # Tailwind configuration
├── tsconfig.json               # TypeScript config
├── next.config.js              # Next.js configuration
├── package.json                # Dependencies
└── README.md                   # This file
```

## 🎨 Customization Guide

### Update Personal Information

Edit `src/app/page.tsx` to update:
- Your name and location
- Headline and sub-roles
- Contact form submission handling

Edit `src/components/About.tsx`:
- Bio text and description
- Experience years
- Specialization areas

### Modify Tech Stack

Update `src/components/TechGrid.tsx`:

```typescript
const techCategories: TechCategory[] = [
  {
    id: 'your-category',
    title: 'Category Name',
    icon: <YourIcon className="w-6 h-6" />,
    tools: ['Tool 1', 'Tool 2', 'Tool 3'],
    color: 'from-color-500/20 to-color-500/10',
    colSpan: 'col-span-1 md:col-span-1',
    rowSpan: 'row-span-1',
  },
];
```

### Add/Edit Projects

Update `src/components/Projects.tsx`:

```typescript
const projects: Project[] = [
  {
    id: 'project-id',
    title: 'Project Name',
    description: 'Short description',
    longDescription: 'Detailed description',
    icon: <IconComponent className="w-8 h-8" />,
    tags: ['Tag1', 'Tag2', 'Tag3'],
    color: 'from-color-500/20 to-color-500/10',
    borderColor: 'border-color-500/30 hover:border-color-500/70',
  },
];
```

### Update Experience Timeline

Edit `src/components/Experience.tsx`:

```typescript
const timeline: TimelineEvent[] = [
  {
    date: 'Your Date',
    title: 'Your Title',
    description: 'Description',
    icon: <IconComponent className="w-6 h-6" />,
    isHighlight: false,
    isPrimary: false,
  },
];
```

### Customize Color Scheme

The default palette uses gold (#f59e0b). To change:

1. Edit `tailwind.config.js` - Update color definitions
2. Update component className strings
3. Adjust gradient colors in CSS

**Current Color Palette:**
- Primary: Gold/Amber (#f59e0b)
- Background: Dark (#0a0e27)
- Secondary: Dark Gray (#1a1f3a)
- Accent: Various shades in tailwind.config.js

### Configure Contact Form

Edit `src/components/Contact.tsx`:

```typescript
const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault();
  setIsLoading(true);
  
  // Add your email service integration here:
  // - SendGrid
  // - EmailJS
  // - Resend
  // - Your backend API
  
  await new Promise((resolve) => setTimeout(resolve, 1500));
  setIsSubmitted(true);
};
```

## 🔧 Configuration Files

### tailwind.config.js

- **Colors:** Customize gold palette and theme colors
- **Animations:** Add custom keyframes and transitions
- **Extensions:** Add custom utilities and components

### next.config.js

- **Image Optimization:** Configure image sizes and formats
- **Headers:** Security headers and SEO meta tags
- **Performance:** Compression and bundle optimization

### tsconfig.json

- **Path Aliases:** Already configured `@/*` for imports
- **Compiler Options:** Strict mode enabled for safety

## 📊 Animation System

The portfolio uses Framer Motion with predefined animation variants in `src/lib/animations.ts`:

### Key Animations:
- `heroVariants` - Hero section entrance
- `containerVariants` - Staggered child animations
- `cardHoverVariants` - 3D tilt on project cards
- `scrollRevealVariants` - Elements reveal on scroll
- `buttonVariants` - Button hover/tap feedback

### Triggering Animations:

```tsx
<motion.div
  initial="hidden"
  whileInView="visible"
  viewport={{ once: true, amount: 0.2 }}
  variants={containerVariants}
>
  Content
</motion.div>
```

## 🚀 Deployment

### Deploy to Vercel (Recommended)

```bash
npm install -g vercel
vercel
```

### Deploy to other platforms:

**GitHub Pages:**
```bash
npm run build
npm install gh-pages --save-dev
# Update next.config.js with basePath config
```

**Netlify:**
```bash
npm run build
# Connect your GitHub repo to Netlify dashboard
```

**Docker:**
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 3000
CMD ["npm", "start"]
```

## 📈 Performance Tips

- Images are optimized with Next.js Image component
- CSS is minified and purged automatically
- JavaScript is code-split for faster loading
- Animations use GPU acceleration (transform/opacity)

### Lighthouse Optimization:
- Disable heavy animations on low-end devices
- Use `prefers-reduced-motion` media query
- Lazy load below-the-fold components
- Minify and compress assets

## 🔒 Security

The following security measures are implemented:

- CSP headers in `next.config.js`
- XSS protection
- CSRF tokens for forms (add if backend needed)
- Security headers configured
- Type-safe with TypeScript

## 🤝 Form Integration

### Option 1: Using EmailJS (No Backend)

```bash
npm install @emailjs/browser
```

```typescript
import emailjs from '@emailjs/browser';

// Initialize in layout
emailjs.init('YOUR_PUBLIC_KEY');

// In handleSubmit:
const templateParams = {
  to_email: 'your@email.com',
  from_name: formData.name,
  from_email: formData.email,
  message: formData.message,
};

emailjs.send('SERVICE_ID', 'TEMPLATE_ID', templateParams);
```

### Option 2: Using Resend

```bash
npm install resend
```

Create `pages/api/email.ts`:

```typescript
import { Resend } from 'resend';

const resend = new Resend(process.env.RESEND_API_KEY);

export default async function POST(request: Request) {
  const { name, email, message } = await request.json();
  
  await resend.emails.send({
    from: 'onboarding@resend.dev',
    to: 'your@email.com',
    subject: `New message from ${name}`,
    html: `<p>${message}</p><p>From: ${email}</p>`,
  });
}
```

### Option 3: Your Own Backend

Connect to your API endpoint in the form handler.

## 📱 Responsive Breakpoints

- **Mobile:** < 640px
- **Tablet:** 640px - 1024px
- **Desktop:** > 1024px

All components use Tailwind's responsive prefixes (sm:, md:, lg:, xl:).

## 🎯 SEO Optimization

- Metadata configured in `layout.tsx`
- Open Graph tags for social sharing
- Twitter card configuration
- Semantic HTML structure
- Mobile viewport configured
- Sitemap ready (add sitemap.xml to public/)

## 🐛 Troubleshooting

### Image not showing?
- Ensure image is in `public/images/` folder
- Check file name in Image src attribute
- Verify image format is supported (PNG, JPG, WebP)

### Animations not working?
- Install Framer Motion: `npm install framer-motion`
- Check console for errors
- Verify animation variants are imported

### Form not submitting?
- Check email service is configured
- Verify API keys/credentials
- Check browser console for errors

### Styling issues?
- Run `npm run build` to ensure Tailwind CSS is generated
- Clear `.next` folder and restart dev server
- Verify tailwind.config.js is in root directory

## 📚 Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [Framer Motion Docs](https://www.framer.com/motion/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)

## 📄 License

This portfolio template is provided as-is for personal use.

## 💬 Support

For issues or customization help:
1. Check the troubleshooting section above
2. Review component comments for usage
3. Consult official documentation links
4. Test in development mode with `npm run dev`

---

**Built with ❤️ for high-performance professionals**

Last Updated: 2025
Version: 1.0.0
