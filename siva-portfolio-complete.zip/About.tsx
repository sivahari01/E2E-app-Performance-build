// components/About.tsx
'use client';

import { motion } from 'framer-motion';
import { containerVariants, itemVariants, titleVariants, scrollRevealVariants } from '@/lib/animations';
import TechGrid from './TechGrid';
import { MapPin, Briefcase } from 'lucide-react';

export default function About() {
  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark via-darkgray to-dark relative overflow-hidden">
      {/* Background elements */}
      <div className="absolute top-0 right-0 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-20 left-20 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>

      <motion.div
        className="max-w-7xl mx-auto relative z-10"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.2 }}
      >
        {/* Section Title */}
        <motion.div
          className="mb-16"
          variants={titleVariants}
        >
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-2">
            About Me
          </h2>
          <div className="w-16 h-1 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full"></div>
        </motion.div>

        {/* Bio Section */}
        <motion.div
          className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-16"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.2 }}
        >
          {/* Main Bio */}
          <motion.div className="lg:col-span-2 space-y-6" variants={itemVariants}>
            <div className="space-y-2">
              <h3 className="text-3xl font-bold text-white">Siva</h3>
              <p className="text-gray-400 flex items-center gap-2">
                <MapPin className="w-4 h-4 text-gold-400" />
                Uthamapalayam, Tamil Nadu
              </p>
            </div>

            <div className="space-y-4 text-gray-300 text-lg leading-relaxed">
              <p>
                I'm a <span className="text-gold-400 font-semibold">Performance Engineer</span> and{' '}
                <span className="text-gold-400 font-semibold">System Reliability Specialist</span> with
                expertise in identifying and resolving the most critical system bottlenecks.
              </p>

              <p>
                My core competencies include deep <span className="text-gold-400 font-semibold">JVM memory analysis</span>,
                {' '}<span className="text-gold-400 font-semibold">connection pool optimization</span> (HikariCP),
                and architecting <span className="text-gold-400 font-semibold">robust microservice ecosystems</span>.
              </p>

              <p>
                I specialize in transforming complex performance challenges into elegant, scalable solutions
                that empower teams to build systems that don't just work—they excel.
              </p>
            </div>
          </motion.div>

          {/* Quick Stats Card */}
          <motion.div
            className="lg:col-span-1"
            variants={itemVariants}
          >
            <motion.div
              className="p-6 rounded-2xl border border-gold-500/20 bg-gradient-to-br from-gold-500/5 via-darkgray to-dark backdrop-blur-sm h-full flex flex-col justify-between"
              whileHover={{
                boxShadow: '0 0 40px rgba(245, 158, 11, 0.2)',
                borderColor: 'rgb(245, 158, 11)',
              }}
              transition={{ duration: 0.3 }}
            >
              <div className="space-y-6">
                <div>
                  <p className="text-gold-400 text-sm font-semibold uppercase tracking-wider mb-1">Experience</p>
                  <p className="text-2xl font-bold text-white">4.5+ Years</p>
                </div>

                <div>
                  <p className="text-gold-400 text-sm font-semibold uppercase tracking-wider mb-1">Focus Areas</p>
                  <div className="space-y-2">
                    <span className="block text-gray-300">Performance Testing</span>
                    <span className="block text-gray-300">System Observability</span>
                    <span className="block text-gray-300">Cloud Architecture</span>
                  </div>
                </div>
              </div>

              <motion.div
                className="mt-6 pt-6 border-t border-gold-500/10"
                initial={{ opacity: 0 }}
                whileInView={{ opacity: 1 }}
                transition={{ delay: 0.3 }}
              >
                <p className="text-gold-300 font-semibold">Passionate about scaling beyond limits</p>
              </motion.div>
            </motion.div>
          </motion.div>
        </motion.div>

        {/* Tech Stack Section */}
        <motion.div
          className="mb-8"
          variants={titleVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true, amount: 0.3 }}
        >
          <h3 className="text-3xl sm:text-4xl font-bold text-white mb-2">
            Tech Stack
          </h3>
          <p className="text-gray-400">Tools and technologies I've mastered</p>
        </motion.div>

        {/* Tech Grid Bento Box */}
        <TechGrid />
      </motion.div>
    </section>
  );
}
