// components/MetricsBar.tsx
'use client';

import { motion } from 'framer-motion';
import { metricsVariants, containerVariants, itemVariants } from '@/lib/animations';
import { useEffect, useState } from 'react';

interface Metric {
  value: string;
  label: string;
  icon?: string;
}

const metrics: Metric[] = [
  { value: '4.5+', label: 'Years Experience' },
  { value: '∞', label: 'Observability Expert' },
  { value: '✓', label: 'Scalability Tested' },
];

export default function MetricsBar() {
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
  }, []);

  if (!mounted) return null;

  return (
    <motion.div
      className="absolute bottom-0 left-0 right-0 h-32 lg:h-auto bg-gradient-to-t from-dark via-dark/80 to-transparent flex items-center justify-center px-4"
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 0.8, duration: 0.6 }}
    >
      <motion.div
        className="max-w-7xl w-full grid grid-cols-3 gap-4 sm:gap-8 py-8 border-t border-gold-500/10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {metrics.map((metric, idx) => (
          <motion.div
            key={idx}
            className="flex flex-col items-center justify-center"
            variants={itemVariants}
          >
            <motion.div
              className="text-2xl sm:text-3xl md:text-4xl font-bold bg-gradient-to-r from-gold-400 to-gold-500 bg-clip-text text-transparent"
              variants={metricsVariants}
            >
              {metric.value}
            </motion.div>
            <motion.p
              className="text-xs sm:text-sm text-gray-400 mt-2 text-center font-medium"
              variants={itemVariants}
            >
              {metric.label}
            </motion.p>
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}
