# 🚀 Quick Start Guide

Get your portfolio live in 5 minutes!

## Step 1: Initialize Project

```bash
# Create Next.js project
npx create-next-app@latest siva-portfolio \
  --typescript \
  --tailwind \
  --no-git \
  --src-dir

# Navigate to project
cd siva-portfolio

# Install dependencies
npm install framer-motion lucide-react
```

## Step 2: Copy Project Files

Copy these files from the provided package to your project:

**Components to `src/components/:`**
- Hero.tsx
- About.tsx
- TechGrid.tsx
- Experience.tsx
- Projects.tsx
- Contact.tsx
- MetricsBar.tsx

**Library files to `src/lib/:`**
- animations.ts

**Configuration files to root:**
- tailwind.config.js
- next.config.js
- tsconfig.json
- package.json (merge dependencies)

**App files to `src/app/:`**
- layout.tsx
- page.tsx
- globals.css

## Step 3: Add Your Photo

1. Create `public/images/` folder
2. Place your photo as `1000089067.png`
3. Recommended: 600x800px or similar portrait/landscape

## Step 4: Update Content

### Edit `src/app/page.tsx`:
- Update navigation links
- Customize hero section

### Edit `src/components/About.tsx`:
- Change name from "Siva"
- Update location
- Modify bio text

### Edit `src/components/TechGrid.tsx`:
- Update tech stack categories
- Add/remove tools

### Edit `src/components/Experience.tsx`:
- Update timeline dates and titles
- Modify milestone descriptions

### Edit `src/components/Projects.tsx`:
- Update project titles and descriptions
- Modify tags and categories

### Edit `src/components/Contact.tsx`:
- Update contact information
- Integrate email service (optional)

## Step 5: Run Development Server

```bash
npm run dev
```

Visit: `http://localhost:3000`

## Step 6: Deploy (Optional)

### Vercel (Recommended)
```bash
npm install -g vercel
vercel
```

### Netlify
1. Push to GitHub
2. Connect repo to Netlify dashboard
3. Auto-deploy on push

### Docker
```bash
docker build -t siva-portfolio .
docker run -p 3000:3000 siva-portfolio
```

## 📝 Customization Checklist

- [ ] Replace hero photo
- [ ] Update name and title
- [ ] Edit About section bio
- [ ] Update tech stack
- [ ] Modify experience timeline
- [ ] Update project descriptions
- [ ] Add contact form integration
- [ ] Customize color scheme (optional)
- [ ] Update social links
- [ ] Deploy to hosting

## 🎨 Quick Color Changes

Open `tailwind.config.js` and change the `gold` color palette:

```javascript
'gold': {
  50: '#fefbf3',
  100: '#fef3e2',
  // ... modify hex values
  500: '#f59e0b',  // Main accent color
  // ...
}
```

## 📊 Form Integration Quick Setup

### Using EmailJS (Easiest)

1. Sign up at [EmailJS](https://www.emailjs.com/)
2. Create email template
3. Copy Service ID, Template ID, Public Key
4. Add to `.env.local`:

```
NEXT_PUBLIC_EMAILJS_SERVICE_ID=your_id
NEXT_PUBLIC_EMAILJS_TEMPLATE_ID=your_id
NEXT_PUBLIC_EMAILJS_PUBLIC_KEY=your_key
```

5. Update `src/components/Contact.tsx` handleSubmit:

```typescript
import emailjs from '@emailjs/browser';

const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
  e.preventDefault();
  setIsLoading(true);
  
  try {
    await emailjs.send(
      process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID!,
      process.env.NEXT_PUBLIC_EMAILJS_TEMPLATE_ID!,
      {
        to_email: 'your@email.com',
        from_name: formData.name,
        from_email: formData.email,
        message: formData.message,
      },
      process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY
    );
    setIsSubmitted(true);
  } catch (error) {
    console.error('Email error:', error);
  } finally {
    setIsLoading(false);
  }
};
```

## 🔧 Common Commands

```bash
# Development
npm run dev          # Start dev server
npm run build        # Build for production
npm start            # Start production server
npm run lint         # Run linter

# Type checking
npm run type-check   # Check TypeScript errors

# Code formatting
npm run format       # Format all files
npm run format:check # Check formatting
```

## 📱 Testing Responsive Design

1. Open browser DevTools (F12)
2. Click device toggle toolbar (Ctrl+Shift+M)
3. Test on different screen sizes

## 🐛 Quick Troubleshooting

**Page doesn't load?**
```bash
rm -rf .next
npm run dev
```

**Image not showing?**
- Check `public/images/` exists
- Verify image filename in code
- Check Next.js Image import

**Animations not working?**
```bash
npm install framer-motion
npm run dev
```

**Styling weird?**
```bash
rm -rf node_modules package-lock.json
npm install
npm run dev
```

## 📞 Support Resources

- [Next.js Docs](https://nextjs.org/docs)
- [Framer Motion Guide](https://www.framer.com/motion/)
- [Tailwind Components](https://tailwindcss.com/docs)
- GitHub Issues in repo

## ✨ Pro Tips

1. **Use Tailwind Intellisense** - Install VSCode extension for autocomplete
2. **Component Preview** - Use React DevTools to inspect components
3. **Animation Testing** - Use Framer Motion's inspector for debugging
4. **Image Optimization** - Use WebP format for smaller file sizes
5. **Performance** - Check Lighthouse scores in DevTools

## 🎯 Next Steps After Setup

1. **SEO Optimization** - Update metadata in `layout.tsx`
2. **Analytics** - Add Google Analytics tracking
3. **Contact Form** - Integrate your email service
4. **Custom Domain** - Point your domain to deployment
5. **SSL Certificate** - Ensure HTTPS (automatic on Vercel/Netlify)

## 📈 Performance Checklist

- [ ] Images optimized
- [ ] CSS minified
- [ ] JavaScript code-split
- [ ] Lazy loading configured
- [ ] Caching headers set
- [ ] Lighthouse score > 90

## 🚀 You're Ready!

Your portfolio is now live. Share it, customize it, and make it your own!

---

**Questions?** Refer to the full README.md for detailed information.
