// components/Hero.tsx
'use client';

import { motion } from 'framer-motion';
import Image from 'next/image';
import { heroVariants, heroImageVariants, buttonVariants, containerVariants, itemVariants } from '@/lib/animations';
import { Download, ArrowRight } from 'lucide-react';
import MetricsBar from './MetricsBar';

export default function Hero() {
  return (
    <section className="min-h-screen flex items-center justify-center pt-20 pb-10 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark via-darkgray to-dark relative overflow-hidden">
      {/* Animated background elements */}
      <div className="absolute top-20 left-10 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-10 right-10 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>

      <motion.div
        className="max-w-7xl w-full grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12 items-center relative z-10"
        variants={containerVariants}
        initial="hidden"
        animate="visible"
      >
        {/* Left Content */}
        <motion.div className="space-y-8" variants={itemVariants}>
          {/* Badge */}
          <motion.div
            className="inline-flex items-center px-4 py-2 rounded-full border border-gold-500/30 bg-gold-500/5 backdrop-blur-sm"
            variants={itemVariants}
          >
            <span className="w-2 h-2 bg-gold-400 rounded-full mr-2 animate-pulse"></span>
            <span className="text-sm font-medium text-gold-300">Performance Engineer</span>
          </motion.div>

          {/* Main Headline */}
          <motion.div variants={itemVariants}>
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight">
              I DON'T JUST WRITE{' '}
              <span className="bg-gradient-to-r from-gold-400 via-gold-300 to-gold-500 bg-clip-text text-transparent">
                CODE.
              </span>
              <br />
              <span className="bg-gradient-to-r from-gold-300 to-gold-500 bg-clip-text text-transparent">
                I ENGINEER SCALABILITY.
              </span>
            </h1>
          </motion.div>

          {/* Sub-roles */}
          <motion.div className="flex flex-wrap gap-3 sm:gap-4" variants={itemVariants}>
            {['Performance Engineer', 'System Reliability', 'Cloud Architecture'].map(
              (role, idx) => (
                <motion.div
                  key={idx}
                  className="px-4 py-2 rounded-lg border border-gold-500/20 bg-gold-500/10 text-gold-300 text-sm font-medium backdrop-blur-sm hover:border-gold-500/50 hover:bg-gold-500/15 transition-all duration-300"
                  whileHover={{ scale: 1.05 }}
                >
                  {role}
                </motion.div>
              )
            )}
          </motion.div>

          {/* Description */}
          <motion.p
            className="text-gray-300 text-lg leading-relaxed max-w-lg"
            variants={itemVariants}
          >
            Specialized in identifying system bottlenecks, analyzing JVM memory metrics, and building
            robust microservice architectures that scale seamlessly.
          </motion.p>

          {/* CTA Buttons */}
          <motion.div className="flex flex-col sm:flex-row gap-4" variants={itemVariants}>
            <motion.button
              className="px-8 py-4 rounded-lg bg-gradient-to-r from-gold-500 to-gold-600 text-dark font-semibold flex items-center justify-center gap-2 hover:shadow-glow-lg transition-all duration-300 group"
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
            >
              Explore My Work
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </motion.button>

            <motion.button
              className="px-8 py-4 rounded-lg border border-gold-500/50 bg-gold-500/5 text-gold-300 font-semibold flex items-center justify-center gap-2 hover:bg-gold-500/15 hover:shadow-glow transition-all duration-300 backdrop-blur-sm"
              variants={buttonVariants}
              whileHover="hover"
              whileTap="tap"
            >
              <Download className="w-5 h-5" />
              Download Resume
            </motion.button>
          </motion.div>
        </motion.div>

        {/* Right Image Section */}
        <motion.div
          className="relative h-[500px] sm:h-[600px] lg:h-[650px] flex items-center justify-center"
          variants={heroImageVariants}
        >
          {/* Decorative frame */}
          <div className="absolute inset-0 rounded-2xl border-2 border-gold-500/20 backdrop-blur-sm"></div>

          {/* Vignette and gradient overlay */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-tr from-dark/60 via-transparent to-gold-500/5"></div>

          {/* Cinematic vignette effect */}
          <div className="absolute inset-0 rounded-2xl shadow-[inset_0_0_60px_rgba(0,0,0,0.8)]"></div>

          {/* Image */}
          <Image
            src="/images/1000089067.png"
            alt="Siva - Performance Engineer"
            fill
            className="object-cover rounded-2xl"
            priority
            sizes="(max-width: 640px) 100vw, (max-width: 1024px) 90vw, 50vw"
          />

          {/* Warm gold overlay */}
          <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-gold-600/10 via-transparent to-gold-900/20 pointer-events-none"></div>

          {/* Glowing border accent */}
          <motion.div
            className="absolute -inset-1 rounded-2xl bg-gradient-to-r from-gold-500 to-gold-600 opacity-0 blur-xl -z-10"
            animate={{
              opacity: [0.2, 0.4, 0.2],
            }}
            transition={{
              duration: 3,
              repeat: Infinity,
            }}
          ></motion.div>
        </motion.div>
      </motion.div>

      {/* Metrics Bar */}
      <MetricsBar />
    </section>
  );
}
