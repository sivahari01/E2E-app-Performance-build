// app/layout.tsx
import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Siva - Performance Engineer & System Reliability Specialist',
  description:
    'High-performance systems architect specializing in JVM optimization, microservice scalability, and observability. Expertise in load testing, cloud architecture, and system reliability.',
  keywords: [
    'Performance Engineer',
    'System Reliability',
    'JVM Optimization',
    'Microservices',
    'Cloud Architecture',
    'Load Testing',
    'Observability',
  ],
  authors: [
    {
      name: 'Siva',
      url: 'https://siva.dev',
    },
  ],
  creator: 'Siva',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://siva.dev',
    title: 'Siva - Performance Engineer',
    description: 'Specializing in system reliability and scalability engineering',
    images: [
      {
        url: '/images/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Siva - Performance Engineer',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Siva - Performance Engineer',
    description: 'Specializing in system reliability and scalability engineering',
    images: ['/images/og-image.png'],
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
        <meta name="theme-color" content="#0a0e27" />
        
        {/* Google Fonts */}
        <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&family=Fira+Code:wght@400;500;700&display=swap" rel="stylesheet" />
        
        {/* Favicon */}
        <link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'><rect fill='%23f59e0b' width='32' height='32' rx='6'/><text x='50%' y='50%' dominantBaseline='middle' textAnchor='middle' font-weight='bold' fill='%23000' font-size='20' font-family='system-ui'>S</text></svg>" />
      </head>
      
      <body className="bg-dark text-white antialiased">
        {children}
      </body>
    </html>
  );
}
