// components/Contact.tsx
'use client';

import { motion } from 'framer-motion';
import { containerVariants, itemVariants, titleVariants, inputVariants } from '@/lib/animations';
import { useState } from 'react';
import { Send, CheckCircle } from 'lucide-react';

export default function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    message: '',
  });
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate form submission
    await new Promise((resolve) => setTimeout(resolve, 1500));

    setIsSubmitted(true);
    setIsLoading(false);

    // Reset form after 3 seconds
    setTimeout(() => {
      setIsSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
    }, 3000);
  };

  return (
    <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gradient-to-b from-dark via-darker to-dark relative overflow-hidden" id="contact">
      {/* Background elements */}
      <div className="absolute top-20 right-0 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-20 w-72 h-72 bg-gold-500 opacity-5 rounded-full blur-3xl"></div>

      <motion.div
        className="max-w-3xl mx-auto relative z-10"
        variants={containerVariants}
        initial="hidden"
        whileInView="visible"
        viewport={{ once: true, amount: 0.3 }}
      >
        {/* Section Title */}
        <motion.div className="mb-16 text-center" variants={titleVariants}>
          <h2 className="text-4xl sm:text-5xl font-bold text-white mb-2">INITIALIZE TRANSMISSION</h2>
          <p className="text-gray-400 text-lg font-mono">Let's discuss your next scalability challenge</p>
          <div className="w-16 h-1 bg-gradient-to-r from-gold-500 to-gold-400 rounded-full mx-auto mt-4"></div>
        </motion.div>

        {/* Terminal Container */}
        <motion.div
          className="rounded-2xl border-2 border-gold-500/30 bg-gradient-to-br from-darkgray via-darker to-dark backdrop-blur-sm overflow-hidden shadow-2xl"
          initial={{ opacity: 0, scale: 0.95 }}
          whileInView={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2, duration: 0.6 }}
          viewport={{ once: true }}
        >
          {/* Terminal Header */}
          <div className="bg-gradient-to-r from-gold-500/20 to-gold-500/10 border-b border-gold-500/20 px-6 py-4 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-3 h-3 rounded-full bg-red-500"></div>
              <div className="w-3 h-3 rounded-full bg-yellow-500"></div>
              <div className="w-3 h-3 rounded-full bg-green-500"></div>
            </div>
            <span className="text-gold-400 font-mono text-sm">contact@siva.dev</span>
            <div className="text-gold-400 font-mono text-sm">bash</div>
          </div>

          {/* Terminal Content */}
          <div className="p-8 min-h-[600px] flex flex-col justify-between">
            {!isSubmitted ? (
              <>
                {/* Terminal welcome message */}
                <motion.div className="mb-8" initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} transition={{ delay: 0.3 }}>
                  <p className="text-gold-400 font-mono text-sm mb-2">$ whoami</p>
                  <p className="text-gray-300 font-mono text-sm">performance.engineer</p>
                  <p className="text-gold-400 font-mono text-sm mt-4">$ message --send</p>
                </motion.div>

                {/* Form */}
                <form onSubmit={handleSubmit} className="space-y-6 flex-1">
                  {/* Name Input */}
                  <motion.div variants={itemVariants}>
                    <label className="text-gold-400 font-mono text-sm block mb-2">NAME:</label>
                    <motion.input
                      type="text"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      placeholder="Enter your name"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-dark border border-gold-500/20 text-white placeholder-gray-500 font-mono text-sm focus:outline-none focus:border-gold-500/70 focus:shadow-glow transition-all duration-300"
                      variants={inputVariants}
                      whileFocus="focus"
                      whileBlur="blur"
                    />
                  </motion.div>

                  {/* Email Input */}
                  <motion.div variants={itemVariants}>
                    <label className="text-gold-400 font-mono text-sm block mb-2">EMAIL:</label>
                    <motion.input
                      type="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      placeholder="your.email@example.com"
                      required
                      className="w-full px-4 py-3 rounded-lg bg-dark border border-gold-500/20 text-white placeholder-gray-500 font-mono text-sm focus:outline-none focus:border-gold-500/70 focus:shadow-glow transition-all duration-300"
                      variants={inputVariants}
                      whileFocus="focus"
                      whileBlur="blur"
                    />
                  </motion.div>

                  {/* Message Input */}
                  <motion.div variants={itemVariants}>
                    <label className="text-gold-400 font-mono text-sm block mb-2">MESSAGE:</label>
                    <motion.textarea
                      name="message"
                      value={formData.message}
                      onChange={handleChange}
                      placeholder="Tell me about your performance engineering needs..."
                      required
                      rows={5}
                      className="w-full px-4 py-3 rounded-lg bg-dark border border-gold-500/20 text-white placeholder-gray-500 font-mono text-sm focus:outline-none focus:border-gold-500/70 focus:shadow-glow transition-all duration-300 resize-none"
                      variants={inputVariants}
                      whileFocus="focus"
                      whileBlur="blur"
                    />
                  </motion.div>

                  {/* Submit Button */}
                  <motion.div className="pt-4" variants={itemVariants}>
                    <motion.button
                      type="submit"
                      disabled={isLoading}
                      className={`w-full px-6 py-3 rounded-lg font-mono font-semibold flex items-center justify-center gap-2 transition-all duration-300 ${
                        isLoading
                          ? 'bg-gold-500/30 text-gold-400 cursor-not-allowed'
                          : 'bg-gradient-to-r from-gold-500 to-gold-600 text-dark hover:shadow-glow-lg active:scale-95'
                      }`}
                      whileHover={!isLoading ? { scale: 1.02 } : {}}
                      whileTap={!isLoading ? { scale: 0.98 } : {}}
                    >
                      {isLoading ? (
                        <>
                          <motion.div
                            animate={{ rotate: 360 }}
                            transition={{ duration: 1, repeat: Infinity, ease: 'linear' }}
                          >
                            ⚙️
                          </motion.div>
                          Sending...
                        </>
                      ) : (
                        <>
                          <Send className="w-5 h-5" />
                          Execute
                        </>
                      )}
                    </motion.button>
                  </motion.div>
                </form>
              </>
            ) : (
              // Success Message
              <motion.div
                className="flex flex-col items-center justify-center h-full text-center"
                initial={{ opacity: 0, scale: 0.8 }}
                animate={{ opacity: 1, scale: 1 }}
                transition={{ duration: 0.5 }}
              >
                <motion.div
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ duration: 0.6 }}
                  className="mb-4"
                >
                  <CheckCircle className="w-16 h-16 text-gold-400 mx-auto" />
                </motion.div>

                <h3 className="text-2xl font-bold text-white mb-2">Transmission Received!</h3>
                <p className="text-gray-400 font-mono text-sm mb-6">
                  Thank you for reaching out. I'll get back to you soon.
                </p>

                <motion.div
                  className="space-y-2 text-gold-400 font-mono text-xs"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  transition={{ delay: 0.3 }}
                >
                  <p>$ status: success ✓</p>
                  <p>$ response_time: 24-48h</p>
                  <p>$ priority: high</p>
                </motion.div>
              </motion.div>
            )}
          </div>

          {/* Terminal Footer */}
          <div className="bg-gradient-to-r from-gold-500/10 to-transparent border-t border-gold-500/20 px-6 py-3">
            <p className="text-gold-400 font-mono text-xs">
              Last updated: {new Date().toLocaleDateString()} • Status: Ready for connection
            </p>
          </div>
        </motion.div>

        {/* Additional Contact Methods */}
        <motion.div
          className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6"
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{ once: true }}
        >
          {[
            {
              label: 'Email',
              value: 'siva@example.com',
              icon: '📧',
            },
            {
              label: 'LinkedIn',
              value: 'linkedin.com/in/siva',
              icon: '🔗',
            },
            {
              label: 'GitHub',
              value: 'github.com/siva',
              icon: '💻',
            },
          ].map((method, idx) => (
            <motion.div
              key={idx}
              className="p-6 rounded-xl border border-gold-500/20 bg-gold-500/5 backdrop-blur-sm text-center hover:border-gold-500/50 hover:bg-gold-500/10 transition-all"
              variants={itemVariants}
              whileHover={{ scale: 1.05, y: -4 }}
            >
              <span className="text-3xl mb-2 block">{method.icon}</span>
              <p className="text-gold-400 font-semibold text-sm mb-1">{method.label}</p>
              <p className="text-gray-400 text-xs font-mono">{method.value}</p>
            </motion.div>
          ))}
        </motion.div>
      </motion.div>
    </section>
  );
}
