# Portfolio Website - Project Structure

## Folder Layout

```
portfolio-website/
├── public/
│   └── images/
│       └── 1000089067.png          # Your hero image
├── src/
│   ├── app/
│   │   ├── layout.tsx
│   │   ├── page.tsx                # Main landing page
│   │   └── globals.css
│   ├── components/
│   │   ├── Hero.tsx
│   │   ├── About.tsx
│   │   ├── Experience.tsx
│   │   ├── Projects.tsx
│   │   ├── Contact.tsx
│   │   ├── TechGrid.tsx
│   │   ├── AnimatedCard.tsx
│   │   ├── MetricsBar.tsx
│   │   └── TerminalInput.tsx
│   ├── lib/
│   │   └── animations.ts           # Framer Motion variants
│   └── styles/
│       └── globals.ts
├── tailwind.config.js
├── next.config.js
├── tsconfig.json
├── package.json
└── .gitignore
```

## Installation & Setup

```bash
# Create Next.js project
npx create-next-app@latest portfolio-website --typescript --tailwind

# Install dependencies
cd portfolio-website
npm install framer-motion lucide-react

# Copy the image to public folder
cp 1000089067.png public/images/

# Run development server
npm run dev
```

## Dependencies Required

```json
{
  "dependencies": {
    "next": "^14.0.0",
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "framer-motion": "^10.16.0",
    "lucide-react": "^0.263.0"
  },
  "devDependencies": {
    "@types/node": "^20.0.0",
    "@types/react": "^18.2.0",
    "@types/react-dom": "^18.2.0",
    "autoprefixer": "^10.4.0",
    "postcss": "^8.4.0",
    "tailwindcss": "^3.3.0",
    "typescript": "^5.0.0"
  }
}
```

## Key Features Implemented

✨ **Dark Theme with Gold Accents** - Premium aesthetic
🎬 **Cinematic Image Effects** - Vignette & gradient overlay
⚡ **Smooth Scroll Animations** - Reveal effects on scroll
🎨 **Bento Box Tech Grid** - Modern layout system
📊 **Interactive Metrics** - Animated counter display
🎯 **3D Hover Effects** - Tilting project cards
💻 **Terminal Contact Form** - Developer-themed interface
📱 **Fully Responsive** - Mobile-first design
