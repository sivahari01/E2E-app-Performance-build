#!/usr/bin/env bash
set -e

echo "==> Installing kind (Kubernetes in Docker)..."
if ! command -v kind &> /dev/null; then
  curl -Lo ./kind https://kind.sigs.k8s.io/dl/v0.23.0/kind-linux-amd64
  chmod +x ./kind
  sudo mv ./kind /usr/local/bin/kind
fi

echo "==> kind version:"
kind version

echo "==> Setup complete."
echo "Next steps:"
echo "  1) bash scripts/build-jars.sh"
echo "  2) bash scripts/build-images.sh"
echo "  3) bash scripts/create-cluster.sh"
echo "  4) bash scripts/deploy.sh"
