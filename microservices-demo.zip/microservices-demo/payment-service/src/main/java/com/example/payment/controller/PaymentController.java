package com.example.payment.controller;

import com.example.payment.model.PaymentRequest;
import com.example.payment.model.PaymentResponse;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.math.BigDecimal;
import java.util.UUID;

@RestController
@RequestMapping("/api/payments")
public class PaymentController {

    // Simulated payment processing: this is a learning project, so we don't call a
    // real payment gateway. Any positive amount "succeeds"; zero or negative "fails".
    @PostMapping
    public ResponseEntity<PaymentResponse> processPayment(@RequestBody PaymentRequest request) {
        String transactionId = "txn_" + UUID.randomUUID();

        if (request.getAmount() == null || request.getAmount().compareTo(BigDecimal.ZERO) <= 0) {
            PaymentResponse response = new PaymentResponse(transactionId, "FAILED", "Invalid payment amount");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        PaymentResponse response = new PaymentResponse(
                transactionId, "SUCCESS",
                "Payment of " + request.getAmount() + " processed for order " + request.getOrderId());
        return ResponseEntity.ok(response);
    }
}
