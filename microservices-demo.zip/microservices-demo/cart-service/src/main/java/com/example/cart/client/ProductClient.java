package com.example.cart.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.Map;

@Component
public class ProductClient {

    private final RestTemplate restTemplate;

    @Value("${services.product-service.url}")
    private String productServiceUrl;

    public ProductClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public ProductInfo getProduct(Long productId) {
        Map<?, ?> response = restTemplate.getForObject(
                productServiceUrl + "/api/products/" + productId, Map.class);
        if (response == null) {
            throw new IllegalStateException("Product not found: " + productId);
        }
        String name = (String) response.get("name");
        BigDecimal price = new BigDecimal(response.get("price").toString());
        return new ProductInfo(productId, name, price);
    }

    public record ProductInfo(Long id, String name, BigDecimal price) {}
}
