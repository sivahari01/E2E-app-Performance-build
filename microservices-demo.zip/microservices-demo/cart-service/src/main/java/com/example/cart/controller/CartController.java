package com.example.cart.controller;

import com.example.cart.client.ProductClient;
import com.example.cart.model.AddItemRequest;
import com.example.cart.model.CartItem;
import com.example.cart.repository.CartItemRepository;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private final CartItemRepository repository;
    private final ProductClient productClient;

    public CartController(CartItemRepository repository, ProductClient productClient) {
        this.repository = repository;
        this.productClient = productClient;
    }

    @GetMapping("/{userId}")
    public List<CartItem> getCart(@PathVariable String userId) {
        return repository.findByUserId(userId);
    }

    @PostMapping("/{userId}/items")
    public ResponseEntity<CartItem> addItem(@PathVariable String userId, @RequestBody AddItemRequest request) {
        ProductClient.ProductInfo product = productClient.getProduct(request.getProductId());
        CartItem item = new CartItem(userId, product.id(), product.name(), product.price(), request.getQuantity());
        return ResponseEntity.ok(repository.save(item));
    }

    @DeleteMapping("/{userId}")
    public ResponseEntity<Void> clearCart(@PathVariable String userId) {
        repository.deleteByUserId(userId);
        return ResponseEntity.noContent().build();
    }
}
