# K8s Microservices Shop — a learning project

A small, deliberately simple e-commerce system built as 5 independent Spring Boot
microservices, designed to teach you how real production microservices get
containerized and deployed to Kubernetes.

```
                        ┌───────────────────┐
                        │  landing-service  │  :8080  (entry point)
                        └─────────┬─────────┘
                                  │ aggregates
                        ┌─────────▼─────────┐
                        │  product-service   │  :8081  (catalog, H2 DB)
                        └────────────────────┘

┌──────────────┐        ┌────────────────────┐        ┌───────────────────┐
│ cart-service │◄───────┤   order-service    ├───────►│ payment-service   │
│    :8082     │        │       :8084        │        │      :8083        │
│  (H2 DB)     │        │ (orchestrates      │        │ (stateless,       │
│ calls        │        │  checkout, H2 DB)  │        │  simulated)       │
│ product-svc  │        └────────────────────┘        └───────────────────┘
└──────────────┘
```

- **landing-service** – the "front door". Serves a tiny static homepage and an
  `/api/landing` endpoint that aggregates featured products from `product-service`.
- **product-service** – product catalog (CRUD), preloaded with 5 sample products.
  Own H2 in-memory database (one DB per service — a core microservices principle).
- **cart-service** – per-user shopping cart. Calls `product-service` to validate
  products and snapshot their price/name when adding an item.
- **payment-service** – stateless, simulated payment gateway. No real payment
  provider is called — this is for learning the *pattern*, not for real money.
- **order-service** – the orchestrator. On checkout it reads the cart, charges
  payment, saves the order, and clears the cart — a simple "saga" you can study
  and later evolve into async messaging.

All inter-service calls use plain `RestTemplate` over HTTP, resolved via
Kubernetes' built-in DNS (`http://<service-name>:<port>`) — no service mesh or
service discovery library needed to get started.

## Repo layout

```
landing-service/    product-service/    cart-service/
payment-service/    order-service/          (each: pom.xml, src/, Dockerfile)
k8s/                 Kubernetes manifests (namespace, configmap, per-service deploy+svc)
scripts/             build / deploy / teardown helper scripts
docker-compose.yml   optional: run everything locally without k8s
.devcontainer/        GitHub Codespaces config (Java, Docker-in-Docker, kubectl, kind)
```

## Option A — Run in GitHub Codespaces (recommended path)

1. Push this folder to a new GitHub repo (see "Getting this into GitHub" below).
2. On the repo page, click **Code → Codespaces → Create codespace on main**.
3. Wait for the container to build — it installs Java 17, Maven, Docker-in-Docker,
   `kubectl`, `helm`, and `kind` for you (see `.devcontainer/devcontainer.json`).
4. In the Codespace terminal, run everything with one command:
   ```bash
   bash scripts/run-all.sh
   ```
   This builds the jars, builds Docker images, creates a local `kind` Kubernetes
   cluster, loads the images into it, and applies all manifests.
5. In a second terminal, forward the entry point:
   ```bash
   bash scripts/port-forward.sh
   ```
   Codespaces will pop up a notification to open port 8080 in the browser — or just:
   ```bash
   curl http://localhost:8080/api/landing
   ```

## Option B — Run locally (Docker Desktop + kind, or Minikube)

Same steps as above, just run them on your own machine instead of a Codespace.
Prereqs: Docker, `kubectl`, and either `kind` or `minikube`.

## Option C — Quick local sanity check with Docker Compose (no k8s)

```bash
bash scripts/build-jars.sh
docker compose up --build
curl http://localhost:8080/api/landing
```
Useful while iterating on code, before you move to the full k8s deployment.

## Trying out the full checkout flow

Once deployed (Option A or B), from inside the cluster network you'd call these
directly; from your terminal, port-forward each service you want to hit, e.g.:

```bash
kubectl -n ecommerce-demo port-forward svc/product-service 8081:8081 &
kubectl -n ecommerce-demo port-forward svc/cart-service 8082:8082 &
kubectl -n ecommerce-demo port-forward svc/order-service 8084:8084 &

# 1. Browse products
curl http://localhost:8081/api/products

# 2. Add product id 1 (qty 2) to user "alice"'s cart
curl -X POST http://localhost:8082/api/cart/alice/items \
  -H "Content-Type: application/json" \
  -d '{"productId": 1, "quantity": 2}'

# 3. Check out — this calls cart-service and payment-service internally
curl -X POST http://localhost:8084/api/orders/alice/checkout

# 4. View alice's order history
curl http://localhost:8084/api/orders/alice
```

## What to explore next (learning ideas)

- **Scale a deployment**: `kubectl -n ecommerce-demo scale deployment product-service --replicas=4`
  and watch requests load-balance across pods.
- **Kill a pod** and watch Kubernetes self-heal it: `kubectl -n ecommerce-demo delete pod <name>`.
- **Autoscaling**: apply `k8s/hpa-example.yaml` (needs `metrics-server`) and generate
  load to see the Horizontal Pod Autoscaler kick in.
- **Ingress**: apply `k8s/ingress-example.yaml` instead of the NodePort service (needs
  an ingress controller like `ingress-nginx` installed first).
- **Rolling updates**: change a message in a controller, rebuild that one image,
  `kind load docker-image`, then `kubectl rollout restart deployment/<svc>` and
  watch `kubectl rollout status` show a zero-downtime update.
- **Resilience**: stop `payment-service`'s pods and see how `order-service`'s
  checkout call behaves — a good motivator for later learning circuit breakers
  (e.g. Resilience4j).
- **Persistence**: replace H2 in-memory with a real Postgres `StatefulSet` +
  `PersistentVolumeClaim` once you're comfortable with the basics here.
- **Observability**: add Prometheus + Grafana, or just `kubectl logs` and
  `kubectl top pods` to see resource usage against the requests/limits set here.

## Getting this into GitHub (so Codespaces can use it)

```bash
cd microservices-demo
git init
git add .
git commit -m "Initial commit: k8s microservices learning project"
gh repo create microservices-demo --public --source=. --push
# or: create an empty repo on github.com, then
#   git remote add origin <your-repo-url>
#   git push -u origin main
```

## Cleaning up

```bash
bash scripts/teardown.sh   # deletes the entire kind cluster
```

## Notes on scope

This is intentionally a *learning* project, not a production template:
- H2 in-memory DBs reset on pod restart (fine for learning; swap for
  Postgres/MySQL + PVCs to go further).
- No auth/API gateway/service mesh, no message queue (all calls are synchronous
  REST) — deliberately kept simple so the Kubernetes concepts stay the focus.
- `payment-service` simulates success/failure locally; it never calls a real
  payment processor.
