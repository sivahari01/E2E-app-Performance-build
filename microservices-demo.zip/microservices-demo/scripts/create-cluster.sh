#!/usr/bin/env bash
# Creates a local Kubernetes cluster using kind (Kubernetes in Docker).
# Safe to re-run: skips creation if the cluster already exists.
set -e
CLUSTER_NAME="microservices-demo"

if kind get clusters | grep -q "^${CLUSTER_NAME}$"; then
  echo "Cluster '$CLUSTER_NAME' already exists."
else
  echo "==> Creating kind cluster: $CLUSTER_NAME"
  kind create cluster --name "$CLUSTER_NAME"
fi

kubectl cluster-info --context "kind-${CLUSTER_NAME}"
