#!/usr/bin/env bash
# Applies all Kubernetes manifests in dependency order.
set -e
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
K8S_DIR="$ROOT_DIR/k8s"

kubectl apply -f "$K8S_DIR/namespace.yaml"
kubectl apply -f "$K8S_DIR/configmap.yaml"

for svc in product-service payment-service cart-service order-service landing-service; do
  echo "==> Deploying $svc"
  kubectl apply -f "$K8S_DIR/$svc/deployment.yaml"
  kubectl apply -f "$K8S_DIR/$svc/service.yaml"
done

echo ""
echo "==> Waiting for pods to become ready (up to 120s each)..."
kubectl -n ecommerce-demo wait --for=condition=available --timeout=120s deployment --all

echo ""
kubectl -n ecommerce-demo get all
