#!/usr/bin/env bash
# Forwards landing-service to localhost:8080 so you can curl/browse it from
# inside the Codespace (Codespaces auto-forwards this port to your browser too).
set -e
kubectl -n ecommerce-demo port-forward svc/landing-service 8080:8080
