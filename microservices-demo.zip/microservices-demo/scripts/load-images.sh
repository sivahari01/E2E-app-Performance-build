#!/usr/bin/env bash
# Loads locally built Docker images into the kind cluster's internal registry,
# since kind clusters can't pull from your host's Docker daemon directly.
set -e
CLUSTER_NAME="microservices-demo"

for svc in landing-service product-service cart-service payment-service order-service; do
  echo "==> Loading $svc:latest into kind"
  kind load docker-image "$svc:latest" --name "$CLUSTER_NAME"
done

echo "All images loaded into the cluster."
