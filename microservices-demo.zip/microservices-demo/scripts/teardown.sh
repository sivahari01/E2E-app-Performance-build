#!/usr/bin/env bash
# Deletes the whole kind cluster, cleaning up everything created for this demo.
set -e
CLUSTER_NAME="microservices-demo"
kind delete cluster --name "$CLUSTER_NAME"
