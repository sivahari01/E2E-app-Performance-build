#!/usr/bin/env bash
# Builds the Maven jar for every microservice. Run this first, and again any
# time you change Java source code, before rebuilding Docker images.
set -e
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

for svc in landing-service product-service cart-service payment-service order-service; do
  echo "==> Building $svc"
  (cd "$ROOT_DIR/$svc" && mvn -q -B clean package -DskipTests)
done

echo "All jars built."
