#!/usr/bin/env bash
# One-shot: build, cluster, load, deploy. Use this after any code change.
set -e
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

bash "$ROOT_DIR/scripts/build-jars.sh"
bash "$ROOT_DIR/scripts/build-images.sh"
bash "$ROOT_DIR/scripts/create-cluster.sh"
bash "$ROOT_DIR/scripts/load-images.sh"
bash "$ROOT_DIR/scripts/deploy.sh"

echo ""
echo "==> Done! Run 'bash scripts/port-forward.sh' in another terminal, then:"
echo "    curl http://localhost:8080/api/landing"
