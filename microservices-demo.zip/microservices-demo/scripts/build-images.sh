#!/usr/bin/env bash
# Builds a Docker image for every microservice.
set -e
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

for svc in landing-service product-service cart-service payment-service order-service; do
  echo "==> Building Docker image for $svc"
  docker build -t "$svc:latest" "$ROOT_DIR/$svc"
done

echo "All images built."
docker images | grep -E "landing-service|product-service|cart-service|payment-service|order-service"
