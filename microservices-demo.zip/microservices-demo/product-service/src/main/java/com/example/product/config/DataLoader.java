package com.example.product.config;

import com.example.product.model.Product;
import com.example.product.repository.ProductRepository;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;

@Component
public class DataLoader implements CommandLineRunner {

    private final ProductRepository repository;

    public DataLoader(ProductRepository repository) {
        this.repository = repository;
    }

    @Override
    public void run(String... args) {
        repository.save(new Product("Mechanical Keyboard", "RGB backlit mechanical keyboard", new BigDecimal("59.99"), 50));
        repository.save(new Product("Wireless Mouse", "Ergonomic wireless mouse", new BigDecimal("24.99"), 100));
        repository.save(new Product("27-inch Monitor", "4K UHD monitor", new BigDecimal("329.00"), 20));
        repository.save(new Product("USB-C Hub", "7-in-1 USB-C hub", new BigDecimal("39.50"), 75));
        repository.save(new Product("Laptop Stand", "Aluminum adjustable laptop stand", new BigDecimal("45.00"), 60));
    }
}
