package com.example.order.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

@Component
public class CartClient {

    private final RestTemplate restTemplate;

    @Value("${services.cart-service.url}")
    private String cartServiceUrl;

    public CartClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @SuppressWarnings("unchecked")
    public List<CartLine> getCart(String userId) {
        List<Map<String, Object>> raw = restTemplate.getForObject(
                cartServiceUrl + "/api/cart/" + userId, List.class);
        if (raw == null) return List.of();
        return raw.stream().map(m -> new CartLine(
                ((Number) m.get("productId")).longValue(),
                (String) m.get("productName"),
                new BigDecimal(m.get("price").toString()),
                ((Number) m.get("quantity")).intValue()
        )).toList();
    }

    public void clearCart(String userId) {
        restTemplate.execute(cartServiceUrl + "/api/cart/" + userId, HttpMethod.DELETE,
                null, null);
    }

    public record CartLine(Long productId, String productName, BigDecimal price, Integer quantity) {
        public BigDecimal lineTotal() {
            return price.multiply(BigDecimal.valueOf(quantity));
        }
    }
}
