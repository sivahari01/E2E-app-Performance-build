package com.example.order.controller;

import com.example.order.client.CartClient;
import com.example.order.client.PaymentClient;
import com.example.order.model.Order;
import com.example.order.repository.OrderRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private final OrderRepository orderRepository;
    private final CartClient cartClient;
    private final PaymentClient paymentClient;

    public OrderController(OrderRepository orderRepository, CartClient cartClient, PaymentClient paymentClient) {
        this.orderRepository = orderRepository;
        this.cartClient = cartClient;
        this.paymentClient = paymentClient;
    }

    @GetMapping("/{userId}")
    public List<Order> getOrders(@PathVariable String userId) {
        return orderRepository.findByUserId(userId);
    }

    /**
     * Checkout flow: read cart -> compute total -> charge payment -> save order -> clear cart.
     * This is the classic "order orchestrates the saga" pattern used to teach
     * inter-service communication in a microservices architecture.
     */
    @PostMapping("/{userId}/checkout")
    public ResponseEntity<Order> checkout(@PathVariable String userId) {
        List<CartClient.CartLine> lines = cartClient.getCart(userId);

        if (lines.isEmpty()) {
            return ResponseEntity.badRequest().build();
        }

        BigDecimal total = lines.stream()
                .map(CartClient.CartLine::lineTotal)
                .reduce(BigDecimal.ZERO, BigDecimal::add);

        String itemsSummary = lines.stream()
                .map(l -> l.quantity() + "x " + l.productName())
                .collect(Collectors.joining(", "));

        Order order = new Order();
        order.setUserId(userId);
        order.setTotalAmount(total);
        order.setItemsSummary(itemsSummary);
        order.setStatus("CREATED");
        order = orderRepository.save(order);

        PaymentClient.PaymentResult payment = paymentClient.charge(
                order.getId().toString(), userId, total);

        order.setPaymentTransactionId(payment.transactionId());
        order.setStatus("SUCCESS".equals(payment.status()) ? "PAID" : "FAILED");
        order = orderRepository.save(order);

        if ("PAID".equals(order.getStatus())) {
            cartClient.clearCart(userId);
            return ResponseEntity.ok(order);
        }

        return ResponseEntity.status(HttpStatus.PAYMENT_REQUIRED).body(order);
    }
}
