package com.example.order.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Component
public class PaymentClient {

    private final RestTemplate restTemplate;

    @Value("${services.payment-service.url}")
    private String paymentServiceUrl;

    public PaymentClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    public PaymentResult charge(String orderId, String userId, BigDecimal amount) {
        Map<String, Object> body = new HashMap<>();
        body.put("orderId", orderId);
        body.put("userId", userId);
        body.put("amount", amount);

        Map<?, ?> response = restTemplate.postForObject(
                paymentServiceUrl + "/api/payments", body, Map.class);
        if (response == null) {
            return new PaymentResult("FAILED", null, "No response from payment-service");
        }
        return new PaymentResult(
                (String) response.get("status"),
                (String) response.get("transactionId"),
                (String) response.get("message"));
    }

    public record PaymentResult(String status, String transactionId, String message) {}
}
