package com.example.landing.controller;

import com.example.landing.client.BackendClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.time.Instant;
import java.util.List;
import java.util.Map;

@RestController
public class LandingController {

    private final BackendClient backendClient;

    public LandingController(BackendClient backendClient) {
        this.backendClient = backendClient;
    }

    /** Aggregator endpoint: the landing page's "home" API, combining data
     * from other microservices into a single response for the client. */
    @GetMapping("/api/landing")
    public Map<String, Object> landing() {
        List<Map<String, Object>> featured = backendClient.getFeaturedProducts();
        return Map.of(
                "message", "Welcome to the K8s Microservices Shop!",
                "timestamp", Instant.now().toString(),
                "featuredProducts", featured
        );
    }
}
