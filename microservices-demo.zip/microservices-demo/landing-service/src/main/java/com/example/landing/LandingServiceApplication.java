package com.example.landing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LandingServiceApplication {
    public static void main(String[] args) {
        SpringApplication.run(LandingServiceApplication.class, args);
    }
}
