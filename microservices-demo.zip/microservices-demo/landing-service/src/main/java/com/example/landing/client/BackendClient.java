package com.example.landing.client;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.List;
import java.util.Map;

@Component
public class BackendClient {

    private final RestTemplate restTemplate;

    @Value("${services.product-service.url}")
    private String productServiceUrl;

    public BackendClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    /** Aggregates featured products for the landing page. Fails soft: returns an
     * empty list (plus a warning upstream) instead of breaking the whole landing page
     * if product-service is temporarily unavailable - a common resilience pattern. */
    @SuppressWarnings("unchecked")
    public List<Map<String, Object>> getFeaturedProducts() {
        try {
            List<Map<String, Object>> products = restTemplate.getForObject(
                    productServiceUrl + "/api/products", List.class);
            return products == null ? List.of() : products;
        } catch (RestClientException ex) {
            return List.of();
        }
    }
}
